# Selenium + ClickHouse + Airflow (СМЭВ 3, документы код 30)

Docker-образ на базе **последней стабильной Debian** с установленными **ClickHouse**, **Apache Airflow**, **Selenium** и **Chromium**. Предназначен для:

- создания инцидентов через СМЭВ 3 (Минфин) по расписанию раз в 15 минут;
- ведения Excel-отчёта по инцидентам (с учётом дубликатов);
- скачивания через СМЭВ паспортов национальных проектов и других документов с кодом 30;
- автоматизации загрузки документов через Airflow DAG и раскладки данных в ClickHouse.

---

## Требования

- Docker и Docker Compose
- Сервер с доступом к каталогу развёртывания (в примере — **10.0.0.1**, каталог **/opt/selenium_clickhouse**)

---

## Установка на сервере 10.0.0.1 в каталог /opt/selenium_clickhouse

### 1. Подготовка каталога на сервере

На сервере **10.0.0.1** создайте и смонтируйте каталог (если он ещё не смонтирован):

```bash
sudo mkdir -p /opt/selenium_clickhouse
sudo chown "$USER:$USER" /opt/selenium_clickhouse
mkdir -p /opt/selenium_clickhouse/{data,reports,logs}
```

При необходимости смонтируйте сюда сетевую шару или используйте существующий диск.

### 2. Копирование проекта в /opt/selenium_clickhouse

Скопируйте содержимое репозитория (папку **Web** или весь проект) в `/opt/selenium_clickhouse` на сервере, например:

```bash
# С вашей рабочей машины (если 10.0.0.1 доступен по SSH):
scp -r Web/* user@10.0.0.1:/opt/selenium_clickhouse/

# Или клонирование репозитория прямо на сервере:
ssh user@10.0.0.1
cd /opt/selenium_clickhouse
git clone <URL_репозитория> .
# либо скопировать только содержимое Web/ в /opt/selenium_clickhouse
```

Минимально нужны файлы:

- `Dockerfile`
- `docker-compose.yml`
- `requirements.txt`
- `scripts/`
- `dags/`
- `clickhouse_schema/`

### 3. Переменные окружения

Создайте файл `.env` в `/opt/selenium_clickhouse` (или задайте переменные в системе):

```bash
cd /opt/selenium_clickhouse
cat > .env << 'EOF'
TZ=Europe/Moscow
SMEV_BASE_URL=https://your-smev3-gateway.example/
SMEV_KEY_ALIAS=your-key-alias
CLICKHOUSE_HOST=clickhouse
CLICKHOUSE_PORT=9000
REPORTS_DIR=/opt/selenium_clickhouse/reports
DATA_DIR=/opt/selenium_clickhouse/data
EOF
```

Подставьте реальные значения `SMEV_BASE_URL` и `SMEV_KEY_ALIAS` по документации СМЭВ 3 / Минфина.

### 4. Сборка образа

```bash
cd /opt/selenium_clickhouse
docker compose build
# или
docker build -t selenium_clickhouse:latest .
```

### 5. Запуск через Docker Compose

Используйте приложенный `docker-compose.yml`:

```bash
cd /opt/selenium_clickhouse
docker compose up -d
```

Будут запущены:

- **clickhouse** — сервер ClickHouse (порты 8123, 9000);
- **selenium_clickhouse** — основной сервис (cron каждые 15 мин, Airflow scheduler + webserver, скрипты).

Тома примонтированы в `/opt/selenium_clickhouse` на хосте (data, reports, logs, dags).

### 6. Инициализация схемы ClickHouse

После первого запуска выполните создание БД и таблиц:

```bash
docker compose exec clickhouse clickhouse-client -q "$(cat clickhouse_schema/init.sql)"
# или по частям:
docker compose exec clickhouse clickhouse-client < clickhouse_schema/init.sql
```

### 7. Проверка

- **Airflow UI**: http://10.0.0.1:8080 (логин/пароль по умолчанию из entrypoint: admin / admin — смените в production).
- **ClickHouse HTTP**: http://10.0.0.1:8123 (например, `SELECT 1`).
- **Логи**:  
  `docker compose logs -f selenium_clickhouse`  
  Отчёт по инцидентам: каталог `reports/` (файл `incidents_report.xlsx`).  
  Скачанные документы: каталог `data/code_30/`.

---

## Структура каталога в контейнере / на хосте

| Путь | Описание |
|------|----------|
| `/opt/selenium_clickhouse` | Рабочий каталог приложения (монтируется с хоста) |
| `data/` | Скачанные документы (в т.ч. `data/code_30/`) |
| `reports/` | Excel-отчёты (инциденты) |
| `logs/` | Логи скриптов и cron |
| `scripts/` | Скрипты инцидентов и загрузки документов |
| `dags/` | DAG’и Airflow |
| `clickhouse_schema/` | SQL-схема для ClickHouse |

---

## Расписание

- **Инциденты СМЭВ**: каждые **15 минут** (cron в контейнере).
- **DAG «smev_documents_code_30»**: по умолчанию **раз в час** (можно изменить `schedule_interval` в `dags/smev_documents_dag.py`).

---

## Дополнительно

- Подробный план доработок и ссылки на мануалы — в **TODO.md**.
- **Тесты**: запуск внутри образа (все зависимости, включая Airflow, установлены):
  ```bash
  cd /opt/selenium_clickhouse
  docker compose run --rm -v $(pwd):/opt/selenium_clickhouse selenium_clickhouse python3 -m pytest tests/ -v
  ```
  Локально (без Airflow): `pip install -r requirements.txt && python3 -m pytest tests/ -v` — тесты DAG будут пропущены, остальные выполнятся.
