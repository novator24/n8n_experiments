-- Таблицы для документов с кодом 30 (паспорта национальных проектов и др.)
-- Выполняется при первом подключении к ClickHouse (или вручную).

CREATE DATABASE IF NOT EXISTS smev_docs;

CREATE TABLE IF NOT EXISTS smev_docs.documents_code_30 (
    id UUID DEFAULT generateUUIDv4(),
    document_id String COMMENT 'ID документа в СМЭВ',
    document_type_code String DEFAULT '30',
    title String,
    received_at DateTime DEFAULT now(),
    file_path String COMMENT 'Локальный путь к файлу',
    source_url String,
    meta String COMMENT 'JSON метаданных'
) ENGINE = MergeTree()
ORDER BY (document_type_code, received_at)
SETTINGS index_granularity = 8192;

CREATE TABLE IF NOT EXISTS smev_docs.incidents_log (
    id UUID DEFAULT generateUUIDv4(),
    incident_id String COMMENT 'ID инцидента СМЭВ',
    created_at DateTime DEFAULT now(),
    title String,
    status String,
    is_duplicate UInt8 DEFAULT 0
) ENGINE = MergeTree()
ORDER BY (created_at, incident_id)
SETTINGS index_granularity = 8192;
