#!/usr/bin/env bash
set -euo pipefail

echo "Selenium-ClickHouse container starting..."
echo "TZ=${TZ:-Europe/Moscow}"

mkdir -p /opt/selenium_clickhouse/data /opt/selenium_clickhouse/reports /opt/selenium_clickhouse/logs
mkdir -p /opt/airflow/dags /opt/airflow/logs

# Инициализация БД Airflow при первом запуске
if [ ! -f /opt/airflow/airflow.db ]; then
    echo "Initializing Airflow database..."
    airflow db init || true
    airflow users create --username admin --password admin --firstname Admin --lastname User --role Admin --email admin@localhost || true
fi

# ClickHouse: в docker-compose обычно поднимается отдельным сервисом (host clickhouse).
# Здесь только клиент; сервер монтируется или поднимается отдельно.

# Запуск планировщика Airflow в фоне
(airflow scheduler &)

# Запуск веб-сервера Airflow в фоне
(airflow webserver --port 8080 &)

# Cron в foreground (инциденты каждые 15 мин)
echo "Starting cron..."
exec cron -f
