#!/usr/bin/env python3
"""
Скрипт создания инцидента через СМЭВ 3 (Минфин) и записи в Excel-отчёт.
Дубли инцидентов добавляются в таблицу отчёта (без повторного создания в СМЭВ при необходимости).
Запускается по крону каждые 15 минут.
"""
import os
import sys
from datetime import datetime
from pathlib import Path

try:
    import requests
    from openpyxl import load_workbook, Workbook
except ImportError:
    print("Install: pip install requests openpyxl", file=sys.stderr)
    sys.exit(1)

REPORTS_DIR = os.environ.get("REPORTS_DIR", "/opt/selenium_clickhouse/reports")
SMEV_BASE_URL = os.environ.get("SMEV_BASE_URL", "")
SMEV_KEY_ALIAS = os.environ.get("SMEV_KEY_ALIAS", "")
REPORT_FILE = Path(REPORTS_DIR) / "incidents_report.xlsx"


def ensure_report_file():
    """Создаёт файл отчёта с заголовками, если его нет."""
    REPORT_FILE.parent.mkdir(parents=True, exist_ok=True)
    if not REPORT_FILE.exists():
        wb = Workbook()
        ws = wb.active
        ws.title = "Инциденты"
        ws.append([
            "Дата/время", "ID инцидента СМЭВ", "Тема", "Статус", "Дубликат"
        ])
        wb.save(REPORT_FILE)
        return load_workbook(REPORT_FILE)
    return load_workbook(REPORT_FILE)


def create_incident_smev(title: str, description: str) -> dict | None:
    """
    Создание инцидента через СМЭВ 3 (универсальный запрос).
    По мануалам: POST с XML-телом, подпись ЭП, возврат requestId.
    """
    if not SMEV_BASE_URL:
        print("SMEV_BASE_URL не задан, используем заглушку", file=sys.stderr)
        return {"requestId": f"stub-{datetime.utcnow().isoformat()}", "status": "stub"}

    # Пример тела по документации СМЭВ 3 (упрощённо)
    # Реальный формат берётся из XSD и регламента Минфина
    payload = {
        "message": f"<incident><title>{title}</title><description>{description}</description></incident>",
        "keyAlias": SMEV_KEY_ALIAS or "default",
    }
    try:
        r = requests.post(
            f"{SMEV_BASE_URL.rstrip('/')}/smev/universal-request/xml",
            json=payload,
            timeout=30,
        )
        r.raise_for_status()
        return r.json()
    except Exception as e:
        print(f"Ошибка СМЭВ: {e}", file=sys.stderr)
        return None


def is_duplicate(wb, incident_id: str) -> bool:
    """Проверка дубликата по ID инцидента в таблице отчёта."""
    ws = wb.active
    for row in ws.iter_rows(min_row=2, min_col=2, max_col=2):
        if row[0].value == incident_id:
            return True
    return False


def append_incident_row(wb, dt: str, incident_id: str, title: str, status: str, is_dup: bool):
    """Добавить строку в Excel (в т.ч. дубликаты)."""
    ws = wb.active
    ws.append([dt, incident_id, title, status, "Да" if is_dup else "Нет"])
    wb.save(REPORT_FILE)


def main():
    now = datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S")
    title = f"Инцидент автоматический {now}"
    description = "Создан скриптом по расписанию (каждые 15 мин)."

    result = create_incident_smev(title, description)
    incident_id = (result or {}).get("requestId") or (result or {}).get("id") or "unknown"
    status = (result or {}).get("status") or "created"

    wb = ensure_report_file()
    dup = is_duplicate(wb, incident_id)
    append_incident_row(wb, now, incident_id, title, status, dup)
    print(f"OK: incident_id={incident_id}, duplicate={dup}")


if __name__ == "__main__":
    main()
