#!/usr/bin/env bash
# Запуск скрипта создания инцидента СМЭВ каждые 15 минут (вызывается из cron)
set -e
export PATH="/usr/local/bin:/usr/bin:/bin"
cd /opt/selenium_clickhouse
python3 scripts/smev_incident.py
