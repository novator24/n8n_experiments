#!/usr/bin/env python3
"""
Скачивание через СМЭВ паспортов национальных проектов и других документов с кодом 30.
Сохраняет файлы в DATA_DIR и может складывать метаданные в ClickHouse (см. DAG).
"""
import os
import sys
from pathlib import Path

try:
    import requests
except ImportError:
    print("Install: pip install requests", file=sys.stderr)
    sys.exit(1)

DATA_DIR = Path(os.environ.get("DATA_DIR", "/opt/selenium_clickhouse/data"))
SMEV_BASE_URL = os.environ.get("SMEV_BASE_URL", "")
DOC_CODE_30 = "30"  # код типа документов (паспорта нацпроектов и др.)


def fetch_documents_by_code(code: str = DOC_CODE_30) -> list[dict]:
    """
    Запрос к СМЭВ на получение списка/документов с кодом 30.
    По мануалам: универсальный запрос с фильтром по коду типа документа.
    """
    if not SMEV_BASE_URL:
        print("SMEV_BASE_URL не задан", file=sys.stderr)
        return []

    url = f"{SMEV_BASE_URL.rstrip('/')}/smev/documents"
    params = {"documentTypeCode": code}
    try:
        r = requests.get(url, params=params, timeout=60)
        r.raise_for_status()
        data = r.json()
        return data if isinstance(data, list) else data.get("items", [data])
    except Exception as e:
        print(f"Ошибка запроса документов: {e}", file=sys.stderr)
        return []


def download_document(doc_id: str, save_dir: Path) -> Path | None:
    """Скачать один документ по ID и сохранить в save_dir."""
    if not SMEV_BASE_URL:
        return None
    url = f"{SMEV_BASE_URL.rstrip('/')}/smev/documents/{doc_id}/content"
    try:
        r = requests.get(url, timeout=120, stream=True)
        r.raise_for_status()
        # Имя файла из Content-Disposition или по doc_id
        name = doc_id
        if "content-disposition" in r.headers:
            cd = r.headers["content-disposition"]
            if "filename=" in cd:
                name = cd.split("filename=")[-1].strip('"\'')
        path = save_dir / name
        path.parent.mkdir(parents=True, exist_ok=True)
        with open(path, "wb") as f:
            for chunk in r.iter_content(8192):
                f.write(chunk)
        return path
    except Exception as e:
        print(f"Ошибка скачивания {doc_id}: {e}", file=sys.stderr)
        return None


def main():
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    docs = fetch_documents_by_code(DOC_CODE_30)
    for doc in docs:
        doc_id = doc.get("id") or doc.get("documentId") or doc.get("requestId")
        if not doc_id:
            continue
        path = download_document(str(doc_id), DATA_DIR / "code_30")
        if path:
            print(f"Downloaded: {path}")


if __name__ == "__main__":
    main()
