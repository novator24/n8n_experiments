"""
Airflow DAG: автоматизация загрузки одного из видов документов с кодом 30 из СМЭВ
и раскладка в ClickHouse.
"""
from datetime import datetime, timedelta
import os

from airflow import DAG
from airflow.operators.python import PythonOperator
from airflow.operators.bash import BashOperator

DEFAULT_ARGS = {
    "owner": "smev",
    "depends_on_past": False,
    "email_on_failure": False,
    "retries": 1,
    "retry_delay": timedelta(minutes=2),
}


def fetch_and_store_documents_code_30(**context):
    """Загрузить документы с кодом 30 и записать метаданные в ClickHouse."""
    from pathlib import Path
    import sys
    sys.path.insert(0, "/opt/selenium_clickhouse")
    from scripts.smev_fetch_docs_30 import fetch_documents_by_code, download_document, DOC_CODE_30

    data_dir = Path(os.environ.get("DATA_DIR", "/opt/selenium_clickhouse/data"))
    ti = context.get("ti")
    log = ti.log if ti else print

    try:
        from clickhouse_driver import Client
    except ImportError:
        log("clickhouse-driver not available, skip DB insert")
        return
    save_dir = data_dir / "code_30"
    save_dir.mkdir(parents=True, exist_ok=True)

    docs = fetch_documents_by_code(DOC_CODE_30)
    host = os.environ.get("CLICKHOUSE_HOST", "clickhouse")
    port = int(os.environ.get("CLICKHOUSE_PORT", "9000"))

    try:
        client = Client(host=host, port=port)
        for doc in docs:
            doc_id = doc.get("id") or doc.get("documentId") or doc.get("requestId")
            if not doc_id:
                continue
            path = download_document(str(doc_id), save_dir)
            if path:
                client.execute(
                    """
                    INSERT INTO smev_docs.documents_code_30
                    (document_id, document_type_code, title, file_path, meta)
                    VALUES (%(document_id)s, %(code)s, %(title)s, %(file_path)s, %(meta)s)
                    """,
                    {
                        "document_id": str(doc_id),
                        "code": DOC_CODE_30,
                        "title": doc.get("title") or doc.get("name") or str(doc_id),
                        "file_path": str(path),
                        "meta": str(doc),
                    },
                )
                log(f"Inserted document {doc_id}")
    except Exception as e:
        log(f"ClickHouse insert failed: {e}")


with DAG(
    dag_id="smev_documents_code_30",
    default_args=DEFAULT_ARGS,
    description="Загрузка документов СМЭВ с кодом 30 и раскладка в ClickHouse",
    schedule_interval=timedelta(hours=1),
    start_date=datetime(2025, 1, 1),
    catchup=False,
    tags=["smev", "documents", "code_30", "clickhouse"],
) as dag:

    fetch_and_store = PythonOperator(
        task_id="fetch_and_store_documents_code_30",
        python_callable=fetch_and_store_documents_code_30,
    )

    init_clickhouse = BashOperator(
        task_id="ensure_clickhouse_schema",
        bash_command="clickhouse-client --host ${CLICKHOUSE_HOST:-clickhouse} -q \"CREATE DATABASE IF NOT EXISTS smev_docs;\" 2>/dev/null || true",
    )

    init_clickhouse >> fetch_and_store
