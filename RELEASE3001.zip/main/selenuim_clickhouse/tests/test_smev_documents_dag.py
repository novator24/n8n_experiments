"""Тесты для DAG smev_documents_code_30 и связанных скриптов."""
import os
import sys
from pathlib import Path
from unittest.mock import patch

import pytest

# Корень проекта
ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

try:
    import airflow
    AIRFLOW_AVAILABLE = True
except ImportError:
    AIRFLOW_AVAILABLE = False


@pytest.mark.skipif(not AIRFLOW_AVAILABLE, reason="Airflow not installed (run tests inside Docker)")
def test_dag_import():
    """DAG должен успешно импортироваться Airflow."""
    os.environ.setdefault("AIRFLOW_HOME", "/opt/airflow")
    with patch.dict(os.environ, {"CLICKHOUSE_HOST": "localhost"}):
        from dags.smev_documents_dag import dag
    assert dag.dag_id == "smev_documents_code_30"
    assert len(dag.tasks) >= 2


@pytest.mark.skipif(not AIRFLOW_AVAILABLE, reason="Airflow not installed (run tests inside Docker)")
def test_dag_tasks_ids():
    """Проверка идентификаторов задач в DAG."""
    os.environ.setdefault("AIRFLOW_HOME", "/opt/airflow")
    with patch.dict(os.environ, {"CLICKHOUSE_HOST": "localhost"}):
        from dags.smev_documents_dag import dag
    task_ids = [t.task_id for t in dag.tasks]
    assert "ensure_clickhouse_schema" in task_ids
    assert "fetch_and_store_documents_code_30" in task_ids


def test_smev_incident_report_creation(tmp_path):
    """Скрипт инцидента создаёт/дополняет Excel-отчёт."""
    with patch.dict(os.environ, {"REPORTS_DIR": str(tmp_path), "SMEV_BASE_URL": ""}):
        import scripts.smev_incident as inc
        inc.REPORT_FILE = tmp_path / "incidents_report.xlsx"
        inc.ensure_report_file()
        assert inc.REPORT_FILE.exists()
        wb = inc.ensure_report_file()
        assert wb.active.title == "Инциденты"
        assert any("ID инцидента" in str(c.value) for c in wb.active[1])


def test_smev_fetch_docs_30_stub():
    """Без SMEV_BASE_URL fetch_documents_by_code возвращает пустой список."""
    with patch.dict(os.environ, {"SMEV_BASE_URL": ""}, clear=False):
        from scripts.smev_fetch_docs_30 import fetch_documents_by_code
        assert fetch_documents_by_code("30") == []


def test_clickhouse_schema_exists():
    """Файл init.sql схемы ClickHouse существует и содержит таблицу."""
    init_sql = ROOT / "clickhouse_schema" / "init.sql"
    assert init_sql.exists()
    text = init_sql.read_text()
    assert "documents_code_30" in text
    assert "smev_docs" in text
