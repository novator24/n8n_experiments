## План интеграции Apache Hop / Airflow / PostgreSQL / PySpark для национальных проектов

Ниже описан общий план работ поверх созданного Docker-образа на Debian с установленными Hop, Airflow, PostgreSQL и PySpark.

### 1. Добавление `src_nat_projects_upd.py` внутрь Docker-образа

- **Шаг 1.1**: создать каталог `src/` внутри проекта `hop` и положить туда скрипт:
  - путь: `hop/src/src_nat_projects_upd.py`;
  - скрипт должен:
    - принимать параметры (через `argparse`) для:
      - даты/диапазона дат,
      - пути к каталогу выгрузки (`/data/input` внутри контейнера),
      - типа документов (паспорт нац. проекта, другие документы с кодом 30),
      - параметров доступа к СМЭВ (endpoint, сертификаты и пр.);
    - подключаться к СМЭВ, используя сертификаты (см. ниже `prod.yaml`);
    - скачивать ZIP/XML/JSON документы паспортов нац. проектов и других документов с кодом 30;
    - сохранять файлы во внутреннем каталоге `/data/input/<тип_документа>/<дата>/`.
- **Шаг 1.2**: в `Dockerfile` уже есть строка `COPY src/ /opt/codebase/src/`:
  - после добавления `src_nat_projects_upd.py` он автоматически окажется в образе по пути `/opt/codebase/src/src_nat_projects_upd.py`;
  - при необходимости обновить `ENTRYPOINT`/DAG так, чтобы Airflow вызывал скрипт:
    - пример команды для операторов: `python /opt/codebase/src/src_nat_projects_upd.py --date {{ ds }} --type passport --output /data/input`.

### 2. Пример раскладки одного документа в PostgreSQL по методологии Data Vault 2.0

- **Шаг 2.1**: в PostgreSQL (БД `hop_vault`) создать DWH-структуру уровня Data Vault 2.0:
  - **Hub**: `hub_nat_project`:
    - `hk_nat_project` (hash key / surrogate key),
    - `bk_nat_project` (business key, например код нац. проекта),
    - `load_dts`, `record_source`.
  - **Satellite**: `sat_nat_project_passport`:
    - `hk_nat_project`,
    - атрибуты паспорта (наименование, куратор, бюджет и т.п.),
    - `effective_from`, `load_dts`, `record_source`, `hash_diff`.
- **Шаг 2.2**: добавить Hop-пайплайн `pipelines/nat_project_passport_to_vault.hpl`:
  - вход:
    - чтение файла паспорта (XML/JSON) из `/data/input/passport/<дата>/`;
  - трансформация:
    - извлечение ключевых полей паспорта,
    - формирование бизнес-ключа `bk_nat_project`,
    - расчёт `hk_nat_project` (SHA-256 от business key + интеграционные атрибуты),
    - расчёт `hash_diff` для сателлита (от изменяемых атрибутов);
  - загрузка:
    - upsert в `hub_nat_project` по `bk_nat_project`,
    - вставка/обновление в `sat_nat_project_passport` на основе `hash_diff` и `effective_from`;
  - пайплайн должен быть настроен на движок Spark (Hop on Spark) для масштабируемой обработки.

### 3. DAG в Airflow для PySpark + Hop

- **Шаг 3.1**: создать DAG `airflow/dags/nat_projects_vault_dag.py` со следующей логикой:
  - `download_nat_docs`:
    - оператор (например, `BashOperator` или `PythonOperator`), который вызывает:
      - `python /opt/codebase/src/src_nat_projects_upd.py --date {{ ds }} --type passport --output /data/input`;
  - `load_passports_to_vault`:
    - оператор (например, `BashOperator` или `SparkSubmitOperator`), который запускает Hop-пайплайн:
      - пример для Bash: `/opt/hop/hop-run.sh -r spark -f /opt/hop/projects/nat_projects/pipelines/nat_project_passport_to_vault.hpl -param:PROCESS_DATE={{ ds }}`;
  - зависимости:
    - `download_nat_docs >> load_passports_to_vault`.
- **Шаг 3.2**: настроить подключения Airflow:
  - соединение к PostgreSQL (`Conn Id: postgres_dwh`) с параметрами:
    - host: `localhost` (или внешний адрес),
    - db: `hop_vault`,
    - user: `hop`,
    - password: `hop`;
  - при использовании `SparkSubmitOperator` — указать master (`local[*]` или внешний кластер Spark) и необходимые `--jars` / `--packages` для доступа к PostgreSQL.

### 4. `test.hpl` для массовой раскладки документов с кодом 30

- **Шаг 4.1**: добавить Hop-пайплайн `pipelines/nat_project_code30_test.hpl`:
  - вход:
    - чтение всех файлов из `/data/input/code30/<дата>/`;
  - общая логика повторяет `nat_project_passport_to_vault.hpl`, но:
    - поддерживает разные типы документов с кодом 30;
    - использует конфигурационную таблицу/файл для маппинга полей документов к структурам Hub/Satellite;
  - выход:
    - загрузка в соответствующие Hub/Satellite таблицы DWH Vault 2.0 по тем же правилам (hash key, hash diff, effective_from).

### 5. Вынос `src_nat_projects_upd.py` за пределы Docker-образа

- **Шаг 5.1**: изменить архитектуру так, чтобы:
  - в самом Docker-образе остались только:
    - Apache Hop + зависимости,
    - PySpark,
    - базовая структура каталогов `/data/input`, `/data/output`;
  - скрипт `src_nat_projects_upd.py` размещался во внешнем репозитории (например, рядом с DAGами в Airflow) и монтировался в контейнер:
    - через volume в Docker (см. ниже про DockerOperator).
- **Шаг 5.2**: в `Dockerfile` оставить только путь для монтирования:
  - например, использовать `/opt/ext/src` как точку монтирования;
  - в DAG вместо `python /opt/codebase/src/src_nat_projects_upd.py` вызывать:
    - `python /opt/ext/src/src_nat_projects_upd.py ...`.

### 6. `prod.yaml` и использование сертификатов `prod_CERT` и `prod_CERT_KEY`

- **Структура `prod.yaml` (пример)**:
  - `prod_CERT`: путь к боевому сертификату (файл `.crt` или `.pem`) на хосте;
  - `prod_CERT_KEY`: путь к приватному ключу (файл `.key`);
  - `smev_endpoint`: URL сервиса СМЭВ;
  - при необходимости: прокси, таймауты, настройки аудита.
- **Использование в скрипте `src_nat_projects_upd.py`**:
  - загрузить `prod.yaml` с помощью `yaml.safe_load`;
  - использовать `prod_CERT` и `prod_CERT_KEY` при формировании TLS-соединения к СМЭВ (requests, aiohttp и пр.);
  - не класть реальные ключи в репозиторий — только примеры путей.

### 7. DAG во внешнем Airflow с DockerOperator для сборки образа и выгрузки в `/ftp` на `10.0.0.1`

- **Шаг 7.1**: во внешнем Airflow создать DAG (например, `build_nat_projects_image_dag.py`) с задачей:
  - `build_and_export_image` (на базе `DockerOperator` или провайдера Docker Build):
    - `image` — имя итогового образа (например, `registry.local/hop-nat-projects:{{ ds }}`);
    - `command` — не используется для сборки, вместо этого:
      - при необходимости использовать `docker build` внутри оператора или специализированный `DockerBuildOperator`;
    - `mounts` / `volumes`:
      - монтировать:
        - каталог с `prod.yaml` и сертификатами;
        - каталог `/ftp` на хосте к, например, `/mnt/ftp` внутри контейнера.
- **Шаг 7.2**: сценарий внутри контейнера (или в операторе) должен:
  - прочитать `prod.yaml`, взять пути `prod_CERT` и `prod_CERT_KEY`;
  - выполнить `docker build` контекста с `Dockerfile` из проекта `hop`:
    - передать сертификаты как build-arg или смонтировать во время сборки, если это допустимо политикой безопасности;
  - сохранить собранный образ в tar-архив:
    - `docker save registry.local/hop-nat-projects:{{ ds }} -o /mnt/ftp/hop-nat-projects-{{ ds }}.tar`;
  - после завершения в каталоге `/ftp` на сервере `10.0.0.1` появится tar-файл образа.

### 8. Проверка пайплайна end-to-end

- **Шаг 8.1**: локальная проверка образа:
  - `docker build -t hop-nat-projects:dev ./hop`;
  - `docker run --rm -p 8080:8080 hop-nat-projects:dev` и убедиться, что:
    - Airflow поднимается,
    - DAG `nat_projects_vault_dag` виден и запускается,
    - Hop-пайплайны доступны по заданным путям.
- **Шаг 8.2**: интеграционная проверка со внешним Airflow:
  - настроить `DockerOperator` на использование Docker Daemon, имеющего доступ к исходникам `hop`;
  - запустить DAG сборки и экспорта образа;
  - убедиться, что файл `.tar` с образом появился в `/ftp` на `10.0.0.1`.

