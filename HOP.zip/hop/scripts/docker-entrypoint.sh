#!/usr/bin/env bash
set -e

export AIRFLOW_HOME=${AIRFLOW_HOME:-/opt/airflow}

initialize_airflow() {
  if [ ! -f "${AIRFLOW_HOME}/airflow.db" ]; then
    echo "[entrypoint] Initializing Airflow metadata database..."
    airflow db init
    airflow users create \
      --role Admin \
      --username admin \
      --password admin \
      --email admin@example.com \
      --firstname Admin \
      --lastname User
  fi
}

start_postgres() {
  echo "[entrypoint] Starting local PostgreSQL (demo only)..."
  service postgresql start
}

start_airflow() {
  echo "[entrypoint] Starting Airflow webserver and scheduler..."
  airflow webserver -p 8080 &
  airflow scheduler &
}

start_postgres
initialize_airflow
start_airflow

echo "[entrypoint] Container is up. Tail logs to keep foreground process..."
tail -f "${AIRFLOW_HOME}/logs/"* || tail -f /dev/null

