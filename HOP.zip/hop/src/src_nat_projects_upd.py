#!/usr/bin/env python3
"""
Скрипт-заготовка для скачивания через СМЭВ паспортов национальных проектов
и других документов с кодом 30.

Назначение:
- Подключиться к СМЭВ с использованием клиентского сертификата и ключа;
- Скачать документы за указанный период;
- Сохранить их в файловой системе для дальнейшей обработки Apache Hop.

Фактическая интеграция с СМЭВ должна быть реализована согласно внутренним
требованиям безопасности и официальной документации СМЭВ. Здесь оставлены
только точки расширения.
"""

import argparse
import datetime as dt
from pathlib import Path
from typing import List

import yaml


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Загрузка паспортов нац. проектов и других документов с кодом 30 через СМЭВ"
    )
    parser.add_argument("--date", dest="date", help="Дата обработки (YYYY-MM-DD)", required=True)
    parser.add_argument(
        "--type",
        dest="doc_type",
        choices=["passport", "code30"],
        default="passport",
        help="Тип документов: passport (паспорт нац. проекта) или code30 (другие доки с кодом 30)",
    )
    parser.add_argument(
        "--output",
        dest="output_dir",
        default="/data/input",
        help="Каталог выгрузки документов внутри контейнера",
    )
    parser.add_argument(
        "--config",
        dest="config_path",
        default="/opt/config/prod.yaml",
        help="Путь к YAML-конфигу с параметрами СМЭВ (prod.yaml)",
    )
    return parser.parse_args()


def load_config(path: str) -> dict:
    cfg_path = Path(path)
    if not cfg_path.exists():
        raise FileNotFoundError(f"Config file not found: {cfg_path}")
    with cfg_path.open("r", encoding="utf-8") as f:
        return yaml.safe_load(f) or {}


def ensure_output_dir(base_dir: str, date: dt.date, doc_type: str) -> Path:
    out = Path(base_dir) / doc_type / date.strftime("%Y-%m-%d")
    out.mkdir(parents=True, exist_ok=True)
    return out


def fetch_documents_from_smev(
    date: dt.date,
    doc_type: str,
    config: dict,
    output_dir: Path,
) -> List[Path]:
    """
    Точка интеграции со СМЭВ.

    Здесь нужно реализовать:
    - формирование запроса (SOAP/REST) в СМЭВ;
    - использование сертификатов:
        config["prod_CERT"], config["prod_CERT_KEY"];
    - выгрузку документов;
    - сохранение каждого документа в output_dir.

    На данный момент функция только показывает ожидаемый интерфейс и
    создаёт пустой файл-заглушку для демонстрации.
    """
    cert_path = config.get("prod_CERT")
    key_path = config.get("prod_CERT_KEY")
    endpoint = config.get("smev_endpoint", "https://smev.example.local")

    print(f"[smev] date={date} type={doc_type}")
    print(f"[smev] endpoint={endpoint}")
    print(f"[smev] cert={cert_path}, key={key_path}")

    # TODO: реализовать запрос к СМЭВ и сохранение реальных данных.
    dummy_file = output_dir / f"{doc_type}_{date.strftime('%Y%m%d')}_example.xml"
    dummy_file.write_text(
        "<document><id>example</id><type>{}</type><date>{}</date></document>".format(
            doc_type,
            date.isoformat(),
        ),
        encoding="utf-8",
    )
    return [dummy_file]


def main() -> None:
    args = parse_args()
    process_date = dt.date.fromisoformat(args.date)
    cfg = load_config(args.config_path)

    out_dir = ensure_output_dir(args.output_dir, process_date, args.doc_type)
    files = fetch_documents_from_smev(
        date=process_date,
        doc_type=args.doc_type,
        config=cfg,
        output_dir=out_dir,
    )

    print(f"[smev] saved {len(files)} file(s) to {out_dir}")


if __name__ == "__main__":
    main()

