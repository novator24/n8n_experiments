"""
DAG для:
- загрузки паспортов нац. проектов и документов с кодом 30 через СМЭВ;
- раскладки данных в PostgreSQL по методологии Data Vault 2.0 с помощью Apache Hop на PySpark.
"""

from datetime import datetime

from airflow import DAG
from airflow.operators.bash import BashOperator

default_args = {
    "owner": "data-platform",
    "depends_on_past": False,
    "retries": 0,
}


with DAG(
    dag_id="nat_projects_vault_dag",
    description="Nat projects passports & code30 -> PostgreSQL DV2.0 via Hop",
    schedule_interval="@daily",
    start_date=datetime(2024, 1, 1),
    catchup=False,
    default_args=default_args,
    tags=["hop", "pyspark", "vault2"],
) as dag:
    download_nat_docs = BashOperator(
        task_id="download_nat_docs",
        bash_command=(
            "python /opt/codebase/src/src_nat_projects_upd.py "
            "--date {{ ds }} --type passport --output /data/input --config /opt/config/prod.yaml"
        ),
    )

    load_passports_to_vault = BashOperator(
        task_id="load_passports_to_vault",
        bash_command=(
            "/opt/hop/hop-run.sh "
            "-r spark "
            "-f /opt/hop/projects/nat_projects/pipelines/nat_project_passport_to_vault.hpl "
            "-param:PROCESS_DATE={{ ds }}"
        ),
    )

    download_nat_docs >> load_passports_to_vault

