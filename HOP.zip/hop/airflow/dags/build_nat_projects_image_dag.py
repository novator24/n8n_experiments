"""
DAG для внешнего Airflow:
- собирает Docker-образ на основе проекта `hop`;
- использует конфиг prod.yaml с ключами prod_CERT и prod_CERT_KEY;
- выгружает результат (docker save) в каталог /ftp, замонтированный с сервера 10.0.0.1.
"""

from datetime import datetime
from pathlib import Path

import yaml
from airflow import DAG
from airflow.operators.bash import BashOperator

default_args = {
    "owner": "data-platform",
    "depends_on_past": False,
    "retries": 0,
}


HOP_PROJECT_DIR = "/opt/hop-project"  # путь к исходникам `hop` внутри DockerOperator
FTP_MOUNT_DIR = "/mnt/ftp"  # каталог, смонтированный в контейнер и соответствующий /ftp на 10.0.0.1
CONFIG_PATH = "/opt/config/prod.yaml"


def _build_docker_commands(**_context) -> str:
    """
    Формирует bash-скрипт для:
    - чтения prod.yaml;
    - сборки Docker-образа;
    - выгрузки образа в tar в /mnt/ftp.
    """
    cfg = {}
    if Path(CONFIG_PATH).exists():
        with open(CONFIG_PATH, "r", encoding="utf-8") as f:
            cfg = yaml.safe_load(f) or {}

    cert = cfg.get("prod_CERT", "/dev/null")
    key = cfg.get("prod_CERT_KEY", "/dev/null")

    # Используем build-arg для передачи путей сертификатов (при необходимости внутри Dockerfile)
    cmds = f"""
set -e
cd {HOP_PROJECT_DIR}
echo "[build] using CERT={cert} KEY={key}"
IMAGE_NAME="hop-nat-projects:{{{{ ds }}}}"

docker build \\
  --build-arg HOP_VERSION=2.8.0 \\
  --build-arg PROD_CERT="{cert}" \\
  --build-arg PROD_CERT_KEY="{key}" \\
  -t "$IMAGE_NAME" .

mkdir -p {FTP_MOUNT_DIR}
docker save "$IMAGE_NAME" -o "{FTP_MOUNT_DIR}/hop-nat-projects-{{{{ ds }}}}.tar"
"""
    return cmds


with DAG(
    dag_id="build_nat_projects_image_dag",
    description="Build & export Hop image with nat projects pipelines",
    schedule_interval=None,
    start_date=datetime(2024, 1, 1),
    catchup=False,
    default_args=default_args,
    tags=["docker", "build", "hop"],
) as dag:
    build_and_export_image = BashOperator(
        task_id="build_and_export_image",
        bash_command="{{ python_callable_result }}",
        env={
            "PYTHONPATH": "/usr/local/airflow",  # опционально
        },
    )

