import os
import json
import datetime as dt
from pathlib import Path

import requests


def get_env(name: str, default: str | None = None, required: bool = False) -> str:
    value = os.getenv(name, default)
    if required and not value:
        raise RuntimeError(f"Required environment variable {name} is not set")
    assert value is not None
    return value


def fetch_get_mis_docs() -> dict:
    """
    Вызов открытого API getMisDocs для получения документов ФЗ-223.
    URL и токен задаются через переменные окружения:
      - FZ223_API_URL
      - FZ223_API_TOKEN
    """
    base_url = get_env("FZ223_API_URL", required=True)
    token = get_env("FZ223_API_TOKEN", default="")

    headers: dict[str, str] = {}
    if token:
        headers["Authorization"] = f"Bearer {token}"

    resp = requests.get(base_url, headers=headers, timeout=60)
    resp.raise_for_status()
    return resp.json()


def save_docs(payload: dict, output_dir: str) -> Path:
    Path(output_dir).mkdir(parents=True, exist_ok=True)
    ts = dt.datetime.now().strftime("%Y%m%d_%H%M%S")
    path = Path(output_dir) / f"fz223_getMisDocs_{ts}.json"
    with path.open("w", encoding="utf-8") as f:
        json.dump(payload, f, ensure_ascii=False, indent=2)
    return path


def main() -> None:
    output_dir = get_env("FZ223_OUTPUT_DIR", default="/opt/app/data")
    data = fetch_get_mis_docs()
    path = save_docs(data, output_dir)
    print(f"Saved getMisDocs payload to {path}")


if __name__ == "__main__":
    main()

