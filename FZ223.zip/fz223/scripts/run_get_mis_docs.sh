#!/usr/bin/env bash
set -euo pipefail

echo "$(date -Iseconds) [INFO] Starting getMisDocs fetch..."

export PYTHONPATH="/opt/app/src:${PYTHONPATH:-}"

python -m fz223_etl.get_mis_docs

echo "$(date -Iseconds) [INFO] Finished getMisDocs fetch."

