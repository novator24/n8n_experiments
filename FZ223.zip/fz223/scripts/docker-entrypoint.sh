#!/usr/bin/env bash
set -euo pipefail

echo "Initializing fz223 container..."
echo "TZ=${TZ}"

# Ensure output dir exists
mkdir -p "${FZ223_OUTPUT_DIR:-/opt/app/data}"

echo "Starting cron in foreground..."
cron -f

