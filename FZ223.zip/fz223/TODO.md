# TODO: Добавление CryptoPro ключей в Docker-образ fz223

## Обзор

Этот сервис `fz223-getmisdocs` периодически забирает документы по открытому API `getMisDocs`. 
Для сценариев, где требуется криптография и электронная подпись, нужно добавить поддержку CryptoPro CSP и ключей.

Ниже приведён конспект типичных шагов (по материалам открытых мануалов в интернете). 
Перед использованием в production обязательно сверяйтесь с **актуальной официальной документацией CryptoPro**.

## 1. Установка CryptoPro CSP в образ

### Вариант A: архив с установщиком

```dockerfile
# Пример фрагмента Dockerfile (должен выполняться от root)
RUN wget https://www.cryptopro.ru/sites/default/files/products/csp/cryptopro_5.0_linux_amd64.tar.gz \
    && tar -xzf cryptopro_5.0_linux_amd64.tar.gz -C /tmp \
    && cd /tmp/cryptopro_5.0_linux_amd64 \
    && ./install.sh \
    && rm -rf /tmp/cryptopro_5.0_linux_amd64*
```

### Вариант B: DEB-пакет

```dockerfile
RUN wget https://www.cryptopro.ru/sites/default/files/products/csp/cryptopro-csp_5.0_amd64.deb \
    && dpkg -i cryptopro-csp_5.0_amd64.deb || apt-get install -f -y \
    && rm cryptopro-csp_5.0_amd64.deb
```

## 2. Установка лицензии

```dockerfile
# Предполагается, что лицензионный файл будет передан как секрет/том
COPY cryptopro/license/license.txt /opt/cryptopro/license.txt

RUN /opt/cprocsp/bin/amd64/cpconfig -license -set /opt/cryptopro/license.txt
```

## 3. Добавление ключей и сертификатов

В образ можно положить примерные ключи и сертификаты, а реальные — монтировать позже.

Пример структуры (в этом репозитории):

- `cryptopro/keys/example.key` — пример закрытого ключа  
- `cryptopro/certs/example.crt` — пример сертификата

```dockerfile
# Копирование примеров ключей
COPY cryptopro/keys/*.key /opt/cryptopro/keys/
COPY cryptopro/certs/*.crt /opt/cryptopro/certs/
```

Альтернативно — импорт через скрипт:

```dockerfile
COPY scripts/import-cryptopro-keys.sh /usr/local/bin/
RUN chmod +x /usr/local/bin/import-cryptopro-keys.sh
```

`import-cryptopro-keys.sh` (пример по мануалам):

```bash
#!/bin/bash

# Импорт закрытого ключа в контейнер пользователя
/opt/cprocsp/bin/amd64/certmgr -inst -store uMy -file /opt/cryptopro/keys/private.key

# Импорт корневого/доверенного сертификата
/opt/cprocsp/bin/amd64/certmgr -inst -store uRoot -file /opt/cryptopro/certs/certificate.crt
```

## 4. Права доступа и переменные окружения

```dockerfile
RUN chmod 600 /opt/cryptopro/keys/*.key \
    && chmod 644 /opt/cryptopro/certs/*.crt \
    && chown -R root:root /opt/cryptopro

ENV CRYPTOPRO_HOME=/opt/cryptopro
ENV PATH=$PATH:/opt/cprocsp/bin/amd64
ENV LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/opt/cprocsp/lib/amd64
```

## 5. Проверка установки

```dockerfile
RUN /opt/cprocsp/bin/amd64/cpconfig -license -view || echo "CryptoPro license check failed"
```

## 6. Использование в Python

В качестве ориентира (конкретная библиотека может отличаться):

```python
from pycryptopro import CryptoPro

crypto = CryptoPro()
signature = crypto.sign(data, key_path="/opt/cryptopro/keys/example.key")
is_valid = crypto.verify(data, signature, cert_path="/opt/cryptopro/certs/example.crt")
```

## 7. Безопасность (обязательно)

- **Не коммитьте реальные ключи и сертификаты** в репозиторий  
- Для production используйте:
  - Docker secrets  
  - защищённые хранилища (Vault и т.п.)  
- Ключи должны передаваться в контейнер либо через тома, либо через секреты, а не через образ

### Пример Docker secrets (docker-compose)

```yaml
services:
  fz223-getmisdocs:
    secrets:
      - cryptopro_private_key
      - cryptopro_certificate

secrets:
  cryptopro_private_key:
    file: ./secrets/private.key
  cryptopro_certificate:
    file: ./secrets/certificate.crt
```

## 8. Чеклист перед production

- [ ] Установлен CryptoPro CSP в образе  
- [ ] Добавлена и активирована лицензия  
- [ ] Добавлены/подключены ключи и сертификаты (безопасным способом)  
- [ ] Настроены права доступа и переменные окружения  
- [ ] Выполнена проверка установки (`cpconfig`, `certmgr`, `cryptcp`)  
- [ ] Приложение использует CryptoPro для подписи/проверки  

