import json
from pathlib import Path
from unittest.mock import patch, MagicMock

import fz223_etl.get_mis_docs as gm


def test_get_env_required_ok(monkeypatch):
    monkeypatch.setenv("TEST_VAR", "value")
    assert gm.get_env("TEST_VAR", required=True) == "value"


def test_get_env_required_missing_raises(monkeypatch):
    monkeypatch.delenv("TEST_VAR", raising=False)
    try:
        gm.get_env("TEST_VAR", required=True)
    except RuntimeError as exc:
        assert "Required environment variable TEST_VAR is not set" in str(exc)
    else:
        assert False, "RuntimeError was not raised"


@patch("fz223_etl.get_mis_docs.requests.get")
def test_fetch_get_mis_docs_uses_url_and_token(mock_get, monkeypatch):
    monkeypatch.setenv("FZ223_API_URL", "https://example.com/api/getMisDocs")
    monkeypatch.setenv("FZ223_API_TOKEN", "secret-token")

    mock_resp = MagicMock()
    mock_resp.json.return_value = {"status": "ok"}
    mock_resp.raise_for_status.return_value = None
    mock_get.return_value = mock_resp

    data = gm.fetch_get_mis_docs()

    assert data == {"status": "ok"}
    mock_get.assert_called_once()
    args, kwargs = mock_get.call_args
    assert args[0] == "https://example.com/api/getMisDocs"
    assert kwargs["headers"]["Authorization"] == "Bearer secret-token"


def test_save_docs_writes_json(tmp_path: Path):
    payload = {"key": "value"}
    out_dir = tmp_path / "out"

    path = gm.save_docs(payload, str(out_dir))

    assert path.exists()
    loaded = json.loads(path.read_text(encoding="utf-8"))
    assert loaded == payload

