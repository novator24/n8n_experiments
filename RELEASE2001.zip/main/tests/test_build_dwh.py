import subprocess
import sys
from pathlib import Path

import importlib


def test_message_constant():
    module = importlib.import_module("scripts.build_dwh")
    assert getattr(module, "MESSAGE") == "построение dwh по открытым данным эб"


def test_main_returns_zero_and_prints_message(tmp_path, monkeypatch):
    """
    Run the module as a script and check stdout.
    """
    project_root = Path(__file__).resolve().parents[1]
    script_path = project_root / "scripts" / "build_dwh.py"

    result = subprocess.run(
        [sys.executable, str(script_path)],
        check=False,
        capture_output=True,
        text=True,
    )

    assert result.returncode == 0
    assert "построение dwh по открытым данным эб" in result.stdout

