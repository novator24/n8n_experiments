from pathlib import Path
import importlib.util


def load_dag_module():
    project_root = Path(__file__).resolve().parents[1]
    dag_path = project_root / "airflow" / "dags" / "dwh_docker_dag.py"
    spec = importlib.util.spec_from_file_location("dwh_docker_dag", dag_path)
    module = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(module)  # type: ignore[arg-type]
    return module


def test_dag_exists_and_has_correct_schedule():
    module = load_dag_module()
    dag = getattr(module, "dag", None)
    assert dag is not None, "DAG object 'dag' must be defined"
    assert dag.dag_id == "dwh_build_docker_dag"
    assert dag.schedule_interval == "0 3 * * *"


def test_docker_task_present():
    module = load_dag_module()
    dag = module.dag
    task_ids = [t.task_id for t in dag.tasks]
    assert "run_dwh_build" in task_ids

