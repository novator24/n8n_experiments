import subprocess
from pathlib import Path


def main() -> int:
    project_root = Path(__file__).resolve().parents[1]
    ansible_dir = project_root / "ansible"

    inventory = ansible_dir / "inventory.ini"
    playbook = ansible_dir / "deploy_web.yml"

    cmd = [
        "ansible-playbook",
        "-i",
        str(inventory),
        str(playbook),
    ]
    print("Running:", " ".join(cmd))
    subprocess.check_call(cmd)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

