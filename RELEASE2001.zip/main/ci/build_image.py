import os
import subprocess
from pathlib import Path


def main() -> int:
    project_root = Path(__file__).resolve().parents[1]
    dockerfile_path = project_root / "Dockerfile"

    image = os.getenv("CI_REGISTRY_IMAGE", "web-release2-0.0.1")
    tag = os.getenv("CI_COMMIT_SHORT_SHA", "latest")
    full_tag = f"{image}:{tag}"

    print(f"Building Docker image {full_tag}")

    cmd = [
        "docker",
        "build",
        "-f",
        str(dockerfile_path),
        "-t",
        full_tag,
        str(project_root),
    ]
    subprocess.check_call(cmd)

    # Если CI_REGISTRY настроен, можно также выполнить docker push.
    if os.getenv("CI_REGISTRY"):
        print(f"Pushing Docker image {full_tag}")
        subprocess.check_call(["docker", "push", full_tag])

    return 0


if __name__ == "__main__":
    raise SystemExit(main())

