from datetime import datetime

from airflow import DAG
from airflow.providers.docker.operators.docker import DockerOperator


default_args = {
    "owner": "airflow",
    "depends_on_past": False,
    "retries": 0,
}


with DAG(
    dag_id="dwh_build_docker_dag",
    description="Перенос расписания из cron: запуск Docker-контейнера для построения DWH по открытым данным ЭБ",
    default_args=default_args,
    schedule_interval="0 3 * * *",  # каждый день в 03:00 (будни и выходные)
    start_date=datetime(2024, 1, 1),
    catchup=False,
    tags=["dwh", "docker"],
) as dag:
    # Используем DockerOperator (DockerDAG-подход), чтобы запускать тот же образ,
    # что и в Dockerfile/docker-compose. Образ и тег можно сконфигурировать через
    # переменные окружения или переменные Airflow.
    image = "{{ var.value.get('dwh_docker_image', 'web-release2-0.0.1') }}:{{ var.value.get('dwh_docker_tag', 'latest') }}"

    run_dwh_build = DockerOperator(
        task_id="run_dwh_build",
        image=image,
        api_version="auto",
        auto_remove=True,
        command="python /opt/app/scripts/build_dwh.py",
        docker_url="unix://var/run/docker.sock",
        network_mode="bridge",
    )

