import sys


MESSAGE = "построение dwh по открытым данным эб"


def main() -> int:
    """
    Simple entry point for the scheduled DWH build job.

    For now it only prints a Russian message required by specification.
    Later this function can be extended with real ETL / DWH logic.
    """
    print(MESSAGE)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

