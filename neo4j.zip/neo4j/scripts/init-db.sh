#!/bin/bash
set -e

echo "Initializing PostgreSQL with PGVector extension..."

# Создание базы данных и пользователя (если не существуют)
psql -v ON_ERROR_STOP=1 --username "$POSTGRES_USER" --dbname "$POSTGRES_DB" <<-EOSQL
    -- Создание базы данных для Airflow
    SELECT 'CREATE DATABASE airflow'
    WHERE NOT EXISTS (SELECT FROM pg_database WHERE datname = 'airflow')\gexec
    
    -- Создание расширения PGVector в dwh_vault
    CREATE EXTENSION IF NOT EXISTS vector;
    
    -- Предоставление прав
    GRANT ALL PRIVILEGES ON DATABASE dwh_vault TO airflow;
    GRANT ALL PRIVILEGES ON DATABASE airflow TO airflow;
EOSQL

# Создание расширения в базе airflow
psql -v ON_ERROR_STOP=1 --username "$POSTGRES_USER" --dbname "airflow" <<-EOSQL
    CREATE EXTENSION IF NOT EXISTS vector;
EOSQL

echo "PostgreSQL initialized successfully!"

