#!/bin/bash
set -e

echo "Starting all services..."

# Инициализация PostgreSQL с PGVector
/usr/local/bin/init-db.sh

# Инициализация MinIO
/usr/local/bin/init-minio.sh

# Запуск Neo4j в фоне
neo4j start &

# Запуск MinIO в фоне
minio server /data --console-address ":9001" &

# Запуск Nexus в фоне
/opt/nexus/bin/nexus start &

# Ожидание готовности PostgreSQL
until pg_isready -h localhost -U airflow; do
  echo "Waiting for PostgreSQL..."
  sleep 2
done

# Инициализация Airflow базы данных (если еще не инициализирована)
if [ ! -f "${AIRFLOW_HOME}/airflow.db" ]; then
  airflow db init
fi

# Создание пользователя Airflow (если еще не создан)
airflow users create \
  --username admin \
  --firstname Admin \
  --lastname User \
  --role Admin \
  --email admin@example.com \
  --password admin || true

# Запуск Airflow webserver в фоне
airflow webserver --port 8080 &

# Запуск Airflow scheduler
airflow scheduler

