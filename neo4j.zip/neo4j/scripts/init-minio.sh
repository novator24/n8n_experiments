#!/bin/bash
set -e

echo "Initializing MinIO..."

# Создание директории для данных MinIO
mkdir -p /data

# Создание bucket для данных ФЗ-44 и ФЗ-223
# Это будет выполнено через MinIO client после запуска сервиса
echo "MinIO initialization completed. Buckets will be created on first run."

