#!/bin/bash
set -e

echo "========================================="
echo "Настройка инфраструктуры данных"
echo "========================================="

# Создание необходимых директорий
echo "Создание директорий..."
mkdir -p logs plugins config cryptopro/keys cryptopro/certs

# Проверка наличия Docker
if ! command -v docker &> /dev/null; then
    echo "Ошибка: Docker не установлен. Установите Docker перед продолжением."
    exit 1
fi

# Проверка наличия docker-compose
if ! command -v docker-compose &> /dev/null; then
    echo "Ошибка: docker-compose не установлен. Установите docker-compose перед продолжением."
    exit 1
fi

# Сборка образов
echo "Сборка Docker образов..."
docker-compose build

# Запуск сервисов
echo "Запуск сервисов..."
docker-compose up -d

# Ожидание готовности сервисов
echo "Ожидание готовности сервисов..."
sleep 30

# Инициализация MinIO
echo "Инициализация MinIO..."
docker exec -it minio-s3 mc alias set myminio http://localhost:9000 minioadmin minioadmin 2>/dev/null || true
docker exec -it minio-s3 mc mb myminio/fz44-data 2>/dev/null || true
docker exec -it minio-s3 mc mb myminio/fz223-data 2>/dev/null || true

# Инициализация PostgreSQL
echo "Инициализация PostgreSQL..."
sleep 10
docker exec -it postgres-dwh psql -U airflow -d dwh_vault -c "CREATE EXTENSION IF NOT EXISTS vector;" 2>/dev/null || true

echo "========================================="
echo "Настройка завершена!"
echo "========================================="
echo ""
echo "Доступ к сервисам:"
echo "  - Airflow: http://localhost:8080 (admin/admin)"
echo "  - Neo4j: http://localhost:7474 (neo4j/neo4j123)"
echo "  - MinIO: http://localhost:9001 (minioadmin/minioadmin)"
echo "  - Nexus: http://localhost:8081"
echo "  - PostgreSQL: localhost:5432 (airflow/airflow)"
echo ""
echo "Для просмотра логов: docker-compose logs -f"
echo "Для остановки: docker-compose down"

