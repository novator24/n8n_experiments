"""
Тесты для MinIO (S3-совместимое хранилище)
"""

import unittest
import boto3
from botocore.exceptions import ClientError


class TestMinIO(unittest.TestCase):
    """Тесты для проверки MinIO"""

    def setUp(self):
        """Инициализация S3 клиента для MinIO"""
        try:
            self.s3_client = boto3.client(
                's3',
                endpoint_url='http://localhost:9000',
                aws_access_key_id='minioadmin',
                aws_secret_access_key='minioadmin'
            )
            # Проверка доступности
            self.s3_client.list_buckets()
        except Exception:
            self.skipTest("MinIO не доступен. Убедитесь, что сервис запущен.")

    def test_connection(self):
        """Проверка подключения к MinIO"""
        self.assertIsNotNone(self.s3_client)
        buckets = self.s3_client.list_buckets()
        self.assertIsInstance(buckets, dict)

    def test_bucket_creation(self):
        """Проверка создания bucket'ов для ФЗ-44 и ФЗ-223"""
        buckets = ['fz44-data', 'fz223-data']
        
        for bucket_name in buckets:
            try:
                self.s3_client.create_bucket(Bucket=bucket_name)
            except ClientError as e:
                if e.response['Error']['Code'] != 'BucketAlreadyOwnedByYou':
                    raise
        
        # Проверка существования bucket'ов
        response = self.s3_client.list_buckets()
        bucket_names = [b['Name'] for b in response['Buckets']]
        
        for bucket_name in buckets:
            self.assertIn(bucket_name, bucket_names)

    def test_file_upload_download(self):
        """Проверка загрузки и скачивания файлов"""
        bucket_name = 'fz44-data'
        test_key = 'test/2025/test_file.txt'
        test_content = b'Test file content for FZ-44'
        
        # Загрузка файла
        self.s3_client.put_object(
            Bucket=bucket_name,
            Key=test_key,
            Body=test_content
        )
        
        # Скачивание файла
        response = self.s3_client.get_object(
            Bucket=bucket_name,
            Key=test_key
        )
        
        downloaded_content = response['Body'].read()
        self.assertEqual(downloaded_content, test_content)
        
        # Удаление тестового файла
        self.s3_client.delete_object(
            Bucket=bucket_name,
            Key=test_key
        )


if __name__ == '__main__':
    unittest.main()

