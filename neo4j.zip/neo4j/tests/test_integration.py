"""
Интеграционные тесты для проверки работы всех компонентов вместе
"""

import unittest
import time
from pyspark.sql import SparkSession
import boto3
import psycopg2


class TestIntegration(unittest.TestCase):
    """Интеграционные тесты"""

    @classmethod
    def setUpClass(cls):
        """Инициализация для всех тестов"""
        cls.spark = SparkSession.builder \
            .appName("IntegrationTest") \
            .master("local[2]") \
            .getOrCreate()
        
        cls.s3_client = boto3.client(
            's3',
            endpoint_url='http://localhost:9000',
            aws_access_key_id='minioadmin',
            aws_secret_access_key='minioadmin'
        )

    @classmethod
    def tearDownClass(cls):
        """Очистка после всех тестов"""
        cls.spark.stop()

    def test_full_etl_pipeline(self):
        """Тест полного ETL пайплайна"""
        # 1. Создание тестовых данных
        test_data = [
            ("1", "CONTRACT-001", "2025-01-15", "2025-01-20", 1000000.00, "RUB"),
            ("2", "CONTRACT-002", "2025-02-20", "2025-02-25", 2000000.00, "RUB"),
        ]
        
        from pyspark.sql.types import StructType, StructField, StringType, DecimalType
        schema = StructType([
            StructField("id", StringType(), True),
            StructField("number", StringType(), True),
            StructField("publishDate", StringType(), True),
            StructField("signDate", StringType(), True),
            StructField("price", DecimalType(15, 2), True),
            StructField("currency", StringType(), True),
        ])
        
        df = self.spark.createDataFrame(test_data, schema)
        
        # 2. Сохранение в S3 (MinIO)
        bucket_name = 'fz44-data'
        try:
            self.s3_client.create_bucket(Bucket=bucket_name)
        except:
            pass
        
        # Сохранение как CSV
        df.coalesce(1).write \
            .mode("overwrite") \
            .option("header", "true") \
            .csv(f"s3a://{bucket_name}/test/2025/")
        
        # 3. Чтение из S3
        df_read = self.spark.read \
            .option("header", "true") \
            .option("inferSchema", "true") \
            .csv(f"s3a://{bucket_name}/test/2025/")
        
        self.assertEqual(df_read.count(), 2)
        
        # 4. Трансформация в Data Vault формат
        from pyspark.sql.functions import col, current_timestamp
        
        hub_df = df_read.select(
            col("id").alias("hub_key"),
            col("id").alias("source_system"),
            current_timestamp().alias("load_timestamp")
        ).distinct()
        
        satellite_df = df_read.select(
            col("id").alias("hub_key"),
            col("number").alias("contract_number"),
            col("publishDate").alias("publish_date"),
            col("signDate").alias("sign_date"),
            col("price").alias("contract_price"),
            col("currency").alias("currency_code"),
            current_timestamp().alias("load_timestamp")
        )
        
        # 5. Загрузка в PostgreSQL
        try:
            conn = psycopg2.connect(
                host="localhost",
                port=5432,
                user="airflow",
                password="airflow",
                database="dwh_vault"
            )
            
            db_properties = {
                "user": "airflow",
                "password": "airflow",
                "driver": "org.postgresql.Driver"
            }
            db_url = "jdbc:postgresql://localhost:5432/dwh_vault"
            
            # Загрузка Hub
            hub_df.write \
                .mode("append") \
                .jdbc(url=db_url, table="hub_fz44_contract", properties=db_properties)
            
            # Загрузка Satellite
            satellite_df.write \
                .mode("append") \
                .jdbc(url=db_url, table="sat_fz44_contract", properties=db_properties)
            
            # Проверка данных в PostgreSQL
            with conn.cursor() as cursor:
                cursor.execute("SELECT COUNT(*) FROM hub_fz44_contract;")
                hub_count = cursor.fetchone()[0]
                self.assertGreaterEqual(hub_count, 2)
                
                cursor.execute("SELECT COUNT(*) FROM sat_fz44_contract;")
                sat_count = cursor.fetchone()[0]
                self.assertGreaterEqual(sat_count, 2)
            
            conn.close()
        except psycopg2.OperationalError:
            self.skipTest("PostgreSQL не доступен для интеграционного теста")


if __name__ == '__main__':
    unittest.main()

