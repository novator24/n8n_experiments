"""
Тесты для Neo4j
"""

import unittest
from neo4j import GraphDatabase


class TestNeo4j(unittest.TestCase):
    """Тесты для проверки Neo4j"""

    def setUp(self):
        """Инициализация подключения к Neo4j"""
        try:
            self.driver = GraphDatabase.driver(
                "bolt://localhost:7687",
                auth=("neo4j", "neo4j123")
            )
            # Проверка подключения
            self.driver.verify_connectivity()
        except Exception:
            self.skipTest("Neo4j не доступен. Убедитесь, что сервис запущен.")

    def tearDown(self):
        """Закрытие подключения"""
        if hasattr(self, 'driver'):
            self.driver.close()

    def test_connection(self):
        """Проверка подключения к Neo4j"""
        self.assertIsNotNone(self.driver)
        self.driver.verify_connectivity()

    def test_create_node(self):
        """Проверка создания узла"""
        with self.driver.session() as session:
            result = session.run(
                "CREATE (n:TestNode {name: $name}) RETURN n",
                name="Test Node"
            )
            node = result.single()
            self.assertIsNotNone(node)

    def test_query_nodes(self):
        """Проверка запроса узлов"""
        with self.driver.session() as session:
            result = session.run("MATCH (n:TestNode) RETURN n LIMIT 1")
            record = result.single()
            if record:
                self.assertIsNotNone(record['n'])

    def test_create_relationship(self):
        """Проверка создания связи"""
        with self.driver.session() as session:
            result = session.run("""
                CREATE (a:NodeA {id: 1})
                CREATE (b:NodeB {id: 2})
                CREATE (a)-[r:RELATES_TO]->(b)
                RETURN r
            """)
            relationship = result.single()
            self.assertIsNotNone(relationship)


if __name__ == '__main__':
    unittest.main()

