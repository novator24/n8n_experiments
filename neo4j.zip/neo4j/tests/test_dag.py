"""
Тесты для Airflow DAG
"""

import unittest
from datetime import datetime
from airflow.models import DagBag
import sys
import os

# Добавление пути к DAG
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '../dags'))


class TestDAG(unittest.TestCase):
    """Тесты для проверки корректности DAG"""

    def setUp(self):
        """Инициализация тестового окружения"""
        self.dagbag = DagBag(dag_folder='../dags', include_examples=False)

    def test_dag_loaded(self):
        """Проверка загрузки DAG"""
        dag = self.dagbag.get_dag(dag_id='fz44_fz223_etl_pipeline')
        self.assertIsNotNone(dag)
        self.assertEqual(len(dag.tasks), 4)

    def test_dag_schedule(self):
        """Проверка расписания DAG"""
        dag = self.dagbag.get_dag(dag_id='fz44_fz223_etl_pipeline')
        self.assertEqual(dag.schedule_interval, '0 9 * * *')  # Каждый день в 09:00

    def test_dag_tasks(self):
        """Проверка наличия всех задач в DAG"""
        dag = self.dagbag.get_dag(dag_id='fz44_fz223_etl_pipeline')
        task_ids = [task.task_id for task in dag.tasks]
        
        self.assertIn('extract_fz44_data', task_ids)
        self.assertIn('extract_fz223_data', task_ids)
        self.assertIn('transform_data', task_ids)
        self.assertIn('load_to_dwh', task_ids)

    def test_dag_dependencies(self):
        """Проверка зависимостей между задачами"""
        dag = self.dagbag.get_dag(dag_id='fz44_fz223_etl_pipeline')
        
        extract_fz44 = dag.get_task('extract_fz44_data')
        extract_fz223 = dag.get_task('extract_fz223_data')
        transform = dag.get_task('transform_data')
        load = dag.get_task('load_to_dwh')
        
        # Проверка зависимостей
        self.assertIn(extract_fz44, transform.upstream_list)
        self.assertIn(extract_fz223, transform.upstream_list)
        self.assertIn(transform, load.upstream_list)

    def test_no_import_errors(self):
        """Проверка отсутствия ошибок импорта"""
        self.assertEqual(len(self.dagbag.import_errors), 0, 
                        f"DAG import errors: {self.dagbag.import_errors}")


if __name__ == '__main__':
    unittest.main()

