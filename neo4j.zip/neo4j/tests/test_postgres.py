"""
Тесты для PostgreSQL и PGVector
"""

import unittest
import psycopg2
from psycopg2.extensions import ISOLATION_LEVEL_AUTOCOMMIT


class TestPostgreSQL(unittest.TestCase):
    """Тесты для проверки PostgreSQL и PGVector"""

    def setUp(self):
        """Инициализация подключения к PostgreSQL"""
        try:
            self.conn = psycopg2.connect(
                host="localhost",
                port=5432,
                user="airflow",
                password="airflow",
                database="dwh_vault"
            )
            self.conn.set_isolation_level(ISOLATION_LEVEL_AUTOCOMMIT)
        except psycopg2.OperationalError:
            self.skipTest("PostgreSQL не доступен. Убедитесь, что сервис запущен.")

    def tearDown(self):
        """Закрытие подключения"""
        if hasattr(self, 'conn'):
            self.conn.close()

    def test_connection(self):
        """Проверка подключения к PostgreSQL"""
        self.assertIsNotNone(self.conn)

    def test_pgvector_extension(self):
        """Проверка наличия расширения PGVector"""
        with self.conn.cursor() as cursor:
            cursor.execute("SELECT * FROM pg_extension WHERE extname = 'vector';")
            result = cursor.fetchone()
            self.assertIsNotNone(result, "PGVector extension не установлен")

    def test_create_tables(self):
        """Проверка создания таблиц Data Vault 2.0"""
        with self.conn.cursor() as cursor:
            # Проверка Hub таблиц
            cursor.execute("""
                SELECT table_name 
                FROM information_schema.tables 
                WHERE table_schema = 'public' 
                AND table_name LIKE 'hub_%';
            """)
            hub_tables = [row[0] for row in cursor.fetchall()]
            
            self.assertIn('hub_fz44_contract', hub_tables)
            self.assertIn('hub_fz223_contract', hub_tables)
            
            # Проверка Satellite таблиц
            cursor.execute("""
                SELECT table_name 
                FROM information_schema.tables 
                WHERE table_schema = 'public' 
                AND table_name LIKE 'sat_%';
            """)
            sat_tables = [row[0] for row in cursor.fetchall()]
            
            self.assertIn('sat_fz44_contract', sat_tables)
            self.assertIn('sat_fz223_contract', sat_tables)

    def test_vector_operations(self):
        """Проверка работы с векторными данными"""
        with self.conn.cursor() as cursor:
            # Создание тестовой таблицы с векторами
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS test_vectors (
                    id SERIAL PRIMARY KEY,
                    embedding vector(128)
                );
            """)
            
            # Вставка тестового вектора
            cursor.execute("""
                INSERT INTO test_vectors (embedding) 
                VALUES ('[1,2,3,4,5]'::vector);
            """)
            
            # Проверка чтения
            cursor.execute("SELECT embedding FROM test_vectors WHERE id = 1;")
            result = cursor.fetchone()
            self.assertIsNotNone(result)
            
            # Очистка
            cursor.execute("DROP TABLE test_vectors;")


if __name__ == '__main__':
    unittest.main()

