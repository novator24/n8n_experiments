"""
Тесты для PySpark операций
"""

import unittest
from pyspark.sql import SparkSession
from pyspark.sql.types import StructType, StructField, StringType, DateType, DecimalType
from datetime import datetime


class TestPySparkOperations(unittest.TestCase):
    """Тесты для проверки PySpark операций"""

    @classmethod
    def setUpClass(cls):
        """Создание Spark сессии для всех тестов"""
        cls.spark = SparkSession.builder \
            .appName("TestPySpark") \
            .master("local[2]") \
            .getOrCreate()

    @classmethod
    def tearDownClass(cls):
        """Закрытие Spark сессии после всех тестов"""
        cls.spark.stop()

    def test_spark_session_created(self):
        """Проверка создания Spark сессии"""
        self.assertIsNotNone(self.spark)
        self.assertEqual(self.spark.sparkContext.appName, "TestPySpark")

    def test_dataframe_creation(self):
        """Проверка создания DataFrame"""
        schema = StructType([
            StructField("id", StringType(), True),
            StructField("number", StringType(), True),
            StructField("publishDate", StringType(), True),
            StructField("price", DecimalType(15, 2), True),
        ])
        
        data = [
            ("1", "CONTRACT-001", "2025-01-15", 1000000.00),
            ("2", "CONTRACT-002", "2025-02-20", 2000000.00),
        ]
        
        df = self.spark.createDataFrame(data, schema)
        self.assertEqual(df.count(), 2)
        self.assertEqual(len(df.columns), 4)

    def test_data_filtering(self):
        """Проверка фильтрации данных по году"""
        from pyspark.sql.functions import year, to_date, col
        
        schema = StructType([
            StructField("id", StringType(), True),
            StructField("publishDate", StringType(), True),
        ])
        
        data = [
            ("1", "2024-12-31"),
            ("2", "2025-01-01"),
            ("3", "2025-06-15"),
            ("4", "2026-01-01"),
        ]
        
        df = self.spark.createDataFrame(data, schema)
        df_with_date = df.withColumn("date", to_date(col("publishDate"), "yyyy-MM-dd"))
        df_2025 = df_with_date.filter(year(col("date")) == 2025)
        
        self.assertEqual(df_2025.count(), 2)

    def test_data_transformation(self):
        """Проверка трансформации данных в формат Data Vault"""
        from pyspark.sql.functions import col
        
        schema = StructType([
            StructField("id", StringType(), True),
            StructField("number", StringType(), True),
            StructField("publishDate", StringType(), True),
            StructField("price", DecimalType(15, 2), True),
        ])
        
        data = [
            ("1", "CONTRACT-001", "2025-01-15", 1000000.00),
        ]
        
        df = self.spark.createDataFrame(data, schema)
        
        # Создание Hub таблицы
        hub_df = df.select(
            col("id").alias("hub_key"),
            col("id").alias("source_system")
        ).distinct()
        
        self.assertEqual(hub_df.count(), 1)
        self.assertIn("hub_key", hub_df.columns)
        self.assertIn("source_system", hub_df.columns)
        
        # Создание Satellite таблицы
        satellite_df = df.select(
            col("id").alias("hub_key"),
            col("number").alias("contract_number"),
            col("publishDate").alias("publish_date"),
            col("price").alias("contract_price")
        )
        
        self.assertEqual(satellite_df.count(), 1)
        self.assertIn("hub_key", satellite_df.columns)
        self.assertIn("contract_number", satellite_df.columns)


if __name__ == '__main__':
    unittest.main()

