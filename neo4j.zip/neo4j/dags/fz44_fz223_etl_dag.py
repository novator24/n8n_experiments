"""
DAG для загрузки данных ФЗ-44 и ФЗ-223 за 2025 год
из S3 в DWH Vault 2.0 в PostgreSQL
"""

from datetime import datetime, timedelta
from airflow import DAG
from airflow.operators.python import PythonOperator
from airflow.providers.postgres.hooks.postgres import PostgresHook
from airflow.providers.amazon.aws.hooks.s3 import S3Hook
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, to_date, year
import boto3
import os

# Параметры подключения
S3_ENDPOINT = "http://minio:9000"
S3_ACCESS_KEY = "minioadmin"
S3_SECRET_KEY = "minioadmin"
S3_BUCKET_FZ44 = "fz44-data"
S3_BUCKET_FZ223 = "fz223-data"
POSTGRES_CONN_ID = "postgres_dwh"

# Расписание: каждый день в 09:00 (будни и выходные)
default_args = {
    'owner': 'data_engineer',
    'depends_on_past': False,
    'start_date': datetime(2025, 1, 1),
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 1,
    'retry_delay': timedelta(minutes=5),
}

dag = DAG(
    'fz44_fz223_etl_pipeline',
    default_args=default_args,
    description='ETL pipeline для загрузки данных ФЗ-44 и ФЗ-223 за 2025 год',
    schedule_interval='0 9 * * *',  # Каждый день в 09:00
    catchup=False,
    tags=['fz44', 'fz223', 'etl', 'pyspark', 'dwh'],
)


def create_spark_session():
    """Создание Spark сессии"""
    spark = SparkSession.builder \
        .appName("FZ44_FZ223_ETL") \
        .config("spark.jars.packages", "org.postgresql:postgresql:42.7.0") \
        .config("spark.sql.warehouse.dir", "/tmp/spark-warehouse") \
        .getOrCreate()
    return spark


def extract_fz44_data(**context):
    """Извлечение данных ФЗ-44 из S3"""
    print("Extracting FZ-44 data from S3...")
    
    # Инициализация S3 клиента
    s3_client = boto3.client(
        's3',
        endpoint_url=S3_ENDPOINT,
        aws_access_key_id=S3_ACCESS_KEY,
        aws_secret_access_key=S3_SECRET_KEY
    )
    
    # Создание Spark сессии
    spark = create_spark_session()
    
    try:
        # Получение списка файлов из S3
        response = s3_client.list_objects_v2(Bucket=S3_BUCKET_FZ44, Prefix='2025/')
        
        if 'Contents' not in response:
            print("No FZ-44 files found in S3")
            return None
        
        # Чтение всех файлов за 2025 год
        file_paths = []
        for obj in response['Contents']:
            if obj['Key'].endswith('.json') or obj['Key'].endswith('.csv'):
                file_path = f"s3a://{S3_BUCKET_FZ44}/{obj['Key']}"
                file_paths.append(file_path)
        
        if not file_paths:
            print("No valid FZ-44 files found")
            return None
        
        # Чтение данных через Spark
        df = spark.read \
            .option("header", "true") \
            .option("inferSchema", "true") \
            .csv(file_paths) if file_paths[0].endswith('.csv') else \
            spark.read.json(file_paths)
        
        # Фильтрация по 2025 году
        df = df.filter(year(to_date(col("publishDate"), "yyyy-MM-dd")) == 2025)
        
        # Сохранение во временную таблицу
        df.createOrReplaceTempView("fz44_raw")
        
        print(f"Extracted {df.count()} records from FZ-44")
        return df
        
    except Exception as e:
        print(f"Error extracting FZ-44 data: {str(e)}")
        raise
    finally:
        spark.stop()


def extract_fz223_data(**context):
    """Извлечение данных ФЗ-223 из S3"""
    print("Extracting FZ-223 data from S3...")
    
    # Инициализация S3 клиента
    s3_client = boto3.client(
        's3',
        endpoint_url=S3_ENDPOINT,
        aws_access_key_id=S3_ACCESS_KEY,
        aws_secret_access_key=S3_SECRET_KEY
    )
    
    # Создание Spark сессии
    spark = create_spark_session()
    
    try:
        # Получение списка файлов из S3
        response = s3_client.list_objects_v2(Bucket=S3_BUCKET_FZ223, Prefix='2025/')
        
        if 'Contents' not in response:
            print("No FZ-223 files found in S3")
            return None
        
        # Чтение всех файлов за 2025 год
        file_paths = []
        for obj in response['Contents']:
            if obj['Key'].endswith('.json') or obj['Key'].endswith('.csv'):
                file_path = f"s3a://{S3_BUCKET_FZ223}/{obj['Key']}"
                file_paths.append(file_path)
        
        if not file_paths:
            print("No valid FZ-223 files found")
            return None
        
        # Чтение данных через Spark
        df = spark.read \
            .option("header", "true") \
            .option("inferSchema", "true") \
            .csv(file_paths) if file_paths[0].endswith('.csv') else \
            spark.read.json(file_paths)
        
        # Фильтрация по 2025 году
        df = df.filter(year(to_date(col("publishDate"), "yyyy-MM-dd")) == 2025)
        
        # Сохранение во временную таблицу
        df.createOrReplaceTempView("fz223_raw")
        
        print(f"Extracted {df.count()} records from FZ-223")
        return df
        
    except Exception as e:
        print(f"Error extracting FZ-223 data: {str(e)}")
        raise
    finally:
        spark.stop()


def transform_data(**context):
    """Трансформация данных в формат Data Vault 2.0"""
    print("Transforming data to Data Vault 2.0 format...")
    
    spark = create_spark_session()
    
    try:
        from pyspark.sql.functions import current_timestamp, lit
        
        # Трансформация ФЗ-44 данных
        try:
            fz44_df = spark.sql("SELECT * FROM fz44_raw")
            
            # Создание Hub таблиц (сущности)
            fz44_hub = fz44_df.select(
                col("id").alias("hub_key"),
                lit("FZ44").alias("source_system"),
                current_timestamp().alias("load_timestamp")
            ).distinct()
            
            # Создание Satellite таблиц (атрибуты)
            fz44_satellite = fz44_df.select(
                col("id").alias("hub_key"),
                col("number").alias("contract_number"),
                col("publishDate").alias("publish_date"),
                col("signDate").alias("sign_date"),
                col("price").alias("contract_price"),
                col("currency").alias("currency_code"),
                current_timestamp().alias("load_timestamp")
            )
            
            # Сохранение трансформированных данных
            fz44_hub.createOrReplaceTempView("fz44_hub")
            fz44_satellite.createOrReplaceTempView("fz44_satellite")
            print("FZ-44 data transformed successfully")
        except Exception as e:
            print(f"Warning: Could not transform FZ-44 data: {str(e)}")
            # Создание пустых таблиц
            spark.sql("SELECT 'empty' as hub_key, 'FZ44' as source_system, current_timestamp() as load_timestamp").limit(0).createOrReplaceTempView("fz44_hub")
            spark.sql("SELECT 'empty' as hub_key, 'empty' as contract_number, current_date() as publish_date, current_date() as sign_date, 0.0 as contract_price, 'RUB' as currency_code, current_timestamp() as load_timestamp").limit(0).createOrReplaceTempView("fz44_satellite")
        
        # Трансформация ФЗ-223 данных
        try:
            fz223_df = spark.sql("SELECT * FROM fz223_raw")
            
            # Создание Hub таблиц
            fz223_hub = fz223_df.select(
                col("id").alias("hub_key"),
                lit("FZ223").alias("source_system"),
                current_timestamp().alias("load_timestamp")
            ).distinct()
            
            # Создание Satellite таблиц
            fz223_satellite = fz223_df.select(
                col("id").alias("hub_key"),
                col("number").alias("contract_number"),
                col("publishDate").alias("publish_date"),
                col("signDate").alias("sign_date"),
                col("price").alias("contract_price"),
                col("currency").alias("currency_code"),
                current_timestamp().alias("load_timestamp")
            )
            
            # Сохранение трансформированных данных
            fz223_hub.createOrReplaceTempView("fz223_hub")
            fz223_satellite.createOrReplaceTempView("fz223_satellite")
            print("FZ-223 data transformed successfully")
        except Exception as e:
            print(f"Warning: Could not transform FZ-223 data: {str(e)}")
            # Создание пустых таблиц
            spark.sql("SELECT 'empty' as hub_key, 'FZ223' as source_system, current_timestamp() as load_timestamp").limit(0).createOrReplaceTempView("fz223_hub")
            spark.sql("SELECT 'empty' as hub_key, 'empty' as contract_number, current_date() as publish_date, current_date() as sign_date, 0.0 as contract_price, 'RUB' as currency_code, current_timestamp() as load_timestamp").limit(0).createOrReplaceTempView("fz223_satellite")
        
        print("Data transformation completed")
        
    except Exception as e:
        print(f"Error transforming data: {str(e)}")
        raise
    finally:
        spark.stop()


def load_to_dwh(**context):
    """Загрузка данных в DWH Vault 2.0 в PostgreSQL"""
    print("Loading data to DWH Vault 2.0...")
    
    spark = create_spark_session()
    conn = None
    
    try:
        # Прямое подключение к PostgreSQL (так как hook может не работать в контейнере)
        import psycopg2
        
        conn = psycopg2.connect(
            host="postgres",
            port=5432,
            user="airflow",
            password="airflow",
            database="dwh_vault"
        )
        conn.autocommit = True
        
        # Создание таблиц Data Vault 2.0 (если не существуют)
        with conn.cursor() as cursor:
            # Hub таблицы
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS hub_fz44_contract (
                    hub_key VARCHAR(255) PRIMARY KEY,
                    source_system VARCHAR(50),
                    load_timestamp TIMESTAMP
                );
            """)
            
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS hub_fz223_contract (
                    hub_key VARCHAR(255) PRIMARY KEY,
                    source_system VARCHAR(50),
                    load_timestamp TIMESTAMP
                );
            """)
            
            # Satellite таблицы
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS sat_fz44_contract (
                    hub_key VARCHAR(255),
                    contract_number VARCHAR(255),
                    publish_date DATE,
                    sign_date DATE,
                    contract_price DECIMAL(15,2),
                    currency_code VARCHAR(10),
                    load_timestamp TIMESTAMP,
                    PRIMARY KEY (hub_key, load_timestamp),
                    FOREIGN KEY (hub_key) REFERENCES hub_fz44_contract(hub_key)
                );
            """)
            
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS sat_fz223_contract (
                    hub_key VARCHAR(255),
                    contract_number VARCHAR(255),
                    publish_date DATE,
                    sign_date DATE,
                    contract_price DECIMAL(15,2),
                    currency_code VARCHAR(10),
                    load_timestamp TIMESTAMP,
                    PRIMARY KEY (hub_key, load_timestamp),
                    FOREIGN KEY (hub_key) REFERENCES hub_fz223_contract(hub_key)
                );
            """)
        
        # Загрузка данных через Spark
        db_properties = {
            "user": "airflow",
            "password": "airflow",
            "driver": "org.postgresql.Driver"
        }
        db_url = "jdbc:postgresql://postgres:5432/dwh_vault"
        
        # Загрузка Hub таблиц
        try:
            fz44_hub_df = spark.sql("SELECT * FROM fz44_hub")
            if fz44_hub_df.count() > 0:
                fz44_hub_df.write \
                    .mode("append") \
                    .jdbc(url=db_url, table="hub_fz44_contract", properties=db_properties)
                print(f"Loaded {fz44_hub_df.count()} records to hub_fz44_contract")
        except Exception as e:
            print(f"Warning: Could not load FZ-44 hub data: {str(e)}")
        
        try:
            fz223_hub_df = spark.sql("SELECT * FROM fz223_hub")
            if fz223_hub_df.count() > 0:
                fz223_hub_df.write \
                    .mode("append") \
                    .jdbc(url=db_url, table="hub_fz223_contract", properties=db_properties)
                print(f"Loaded {fz223_hub_df.count()} records to hub_fz223_contract")
        except Exception as e:
            print(f"Warning: Could not load FZ-223 hub data: {str(e)}")
        
        # Загрузка Satellite таблиц
        try:
            fz44_sat_df = spark.sql("SELECT * FROM fz44_satellite")
            if fz44_sat_df.count() > 0:
                fz44_sat_df.write \
                    .mode("append") \
                    .jdbc(url=db_url, table="sat_fz44_contract", properties=db_properties)
                print(f"Loaded {fz44_sat_df.count()} records to sat_fz44_contract")
        except Exception as e:
            print(f"Warning: Could not load FZ-44 satellite data: {str(e)}")
        
        try:
            fz223_sat_df = spark.sql("SELECT * FROM fz223_satellite")
            if fz223_sat_df.count() > 0:
                fz223_sat_df.write \
                    .mode("append") \
                    .jdbc(url=db_url, table="sat_fz223_contract", properties=db_properties)
                print(f"Loaded {fz223_sat_df.count()} records to sat_fz223_contract")
        except Exception as e:
            print(f"Warning: Could not load FZ-223 satellite data: {str(e)}")
        
        print("Data loaded to DWH Vault 2.0 successfully")
        
    except Exception as e:
        print(f"Error loading data to DWH: {str(e)}")
        raise
    finally:
        spark.stop()
        if conn:
            conn.close()


# Определение задач DAG
extract_fz44_task = PythonOperator(
    task_id='extract_fz44_data',
    python_callable=extract_fz44_data,
    dag=dag,
)

extract_fz223_task = PythonOperator(
    task_id='extract_fz223_data',
    python_callable=extract_fz223_data,
    dag=dag,
)

transform_task = PythonOperator(
    task_id='transform_data',
    python_callable=transform_data,
    dag=dag,
)

load_task = PythonOperator(
    task_id='load_to_dwh',
    python_callable=load_to_dwh,
    dag=dag,
)

# Определение зависимостей
[extract_fz44_task, extract_fz223_task] >> transform_task >> load_task

