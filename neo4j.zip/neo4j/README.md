# Инфраструктура данных для обработки ФЗ-44 и ФЗ-223

Комплексное решение для загрузки и обработки данных о государственных закупках (ФЗ-44 и ФЗ-223) за 2025 год с использованием Apache Airflow, PySpark, PostgreSQL с PGVector, Neo4j, MinIO и Nexus S3.

## Компоненты

- **Debian Bookworm** - базовая операционная система
- **Neo4j** - графовая база данных
- **Apache Spark 3.5.0** - обработка больших данных
- **PySpark** - Python API для Spark
- **Apache Airflow 2.8.0** - оркестрация ETL процессов
- **PostgreSQL 15** - реляционная БД с расширением PGVector
- **MinIO** - S3-совместимое хранилище объектов
- **Nexus Repository** - хранилище артефактов с S3 API
- **CryptoPro** - поддержка криптографических ключей (см. TODO.md)

## Структура проекта

```
.
├── Dockerfile              # Основной Docker образ
├── docker-compose.yml      # Оркестрация сервисов
├── dags/                   # Airflow DAG'и
│   └── fz44_fz223_etl_dag.py
├── config/                 # Конфигурационные файлы
│   ├── airflow.cfg
│   ├── postgresql.conf
│   └── neo4j.conf
├── scripts/                # Скрипты инициализации
│   ├── start-services.sh
│   ├── init-db.sh
│   └── init-minio.sh
├── cryptopro/              # CryptoPro ключи (примеры)
│   ├── keys/
│   └── certs/
├── tests/                  # Тесты
│   ├── test_dag.py
│   ├── test_pyspark.py
│   ├── test_postgres.py
│   ├── test_minio.py
│   ├── test_neo4j.py
│   └── test_integration.py
├── requirements.txt        # Python зависимости
├── TODO.md                 # Инструкции по CryptoPro
└── README.md              # Документация

```

## Быстрый старт

### 1. Сборка и запуск

```bash
# Сборка образов
docker-compose build

# Запуск всех сервисов
docker-compose up -d

# Просмотр логов
docker-compose logs -f
```

### 2. Доступ к сервисам

- **Airflow Web UI**: http://localhost:8080
  - Логин: `admin`
  - Пароль: `admin`
- **Neo4j Browser**: http://localhost:7474
  - Логин: `neo4j`
  - Пароль: `neo4j123`
- **MinIO Console**: http://localhost:9001
  - Логин: `minioadmin`
  - Пароль: `minioadmin`
- **Nexus Repository**: http://localhost:8081
- **PostgreSQL**: `localhost:5432`
  - Пользователь: `airflow`
  - Пароль: `airflow`
  - База данных: `dwh_vault`

### 3. Инициализация данных

```bash
# Создание bucket'ов в MinIO
docker exec -it minio-s3 mc alias set myminio http://localhost:9000 minioadmin minioadmin
docker exec -it minio-s3 mc mb myminio/fz44-data
docker exec -it minio-s3 mc mb myminio/fz223-data

# Загрузка тестовых данных (пример)
# docker exec -it minio-s3 mc cp /path/to/data.csv myminio/fz44-data/2025/
```

## Airflow DAG

DAG `fz44_fz223_etl_pipeline` настроен на автоматический запуск каждый день в 09:00 (будни и выходные).

### Задачи DAG:

1. **extract_fz44_data** - извлечение данных ФЗ-44 из S3
2. **extract_fz223_data** - извлечение данных ФЗ-223 из S3
3. **transform_data** - трансформация в формат Data Vault 2.0
4. **load_to_dwh** - загрузка в PostgreSQL DWH Vault 2.0

### Структура Data Vault 2.0

- **Hub таблицы**: `hub_fz44_contract`, `hub_fz223_contract`
- **Satellite таблицы**: `sat_fz44_contract`, `sat_fz223_contract`

## Запуск тестов

```bash
# Установка зависимостей
pip install -r requirements.txt

# Запуск всех тестов
python -m pytest tests/ -v

# Запуск конкретного теста
python -m pytest tests/test_dag.py -v

# С покрытием кода
python -m pytest tests/ --cov=. --cov-report=html
```

## CryptoPro ключи

См. [TODO.md](TODO.md) для подробных инструкций по добавлению CryptoPro ключей в образ.

⚠️ **Важно**: Примеры ключей в `cryptopro/` директории должны быть заменены на реальные перед использованием в production.

## Расписание запуска

DAG настроен на запуск каждый день в 09:00 через параметр `schedule_interval='0 9 * * *'` в определении DAG.

## Разработка

### Добавление новых DAG'ов

Поместите Python файлы с DAG'ами в директорию `dags/`. Airflow автоматически обнаружит их.

### Изменение конфигурации

- **Airflow**: `config/airflow.cfg`
- **PostgreSQL**: `config/postgresql.conf`
- **Neo4j**: `config/neo4j.conf`

## Troubleshooting

### Проблемы с подключением к сервисам

Убедитесь, что все сервисы запущены:
```bash
docker-compose ps
```

### Проблемы с Airflow

Проверьте логи:
```bash
docker-compose logs airflow-scheduler
docker-compose logs airflow-webserver
```

### Проблемы с PostgreSQL

Проверьте, что расширение PGVector установлено:
```bash
docker exec -it postgres-dwh psql -U airflow -d dwh_vault -c "CREATE EXTENSION IF NOT EXISTS vector;"
```

## Лицензия

Проект создан для внутреннего использования.

## Контакты

Для вопросов и предложений создайте issue в репозитории.

