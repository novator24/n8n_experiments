# TODO: Добавление CryptoPro ключей в Docker образ

## Обзор

CryptoPro - это российская криптографическая библиотека для работы с электронной подписью и шифрованием. Для интеграции CryptoPro ключей в Docker образ необходимо выполнить следующие шаги.

## Инструкции по добавлению CryptoPro ключей

### 1. Установка CryptoPro CSP в Docker образ

#### Вариант A: Использование официального репозитория CryptoPro

```dockerfile
# Добавить в Dockerfile перед установкой других компонентов
RUN wget https://www.cryptopro.ru/sites/default/files/products/csp/cryptopro_5.0_linux_amd64.tar.gz \
    && tar -xzf cryptopro_5.0_linux_amd64.tar.gz -C /tmp \
    && cd /tmp/cryptopro_5.0_linux_amd64 \
    && ./install.sh \
    && rm -rf /tmp/cryptopro_5.0_linux_amd64*
```

#### Вариант B: Использование готового DEB пакета

```dockerfile
# Добавить в Dockerfile
RUN wget https://www.cryptopro.ru/sites/default/files/products/csp/cryptopro-csp_5.0_amd64.deb \
    && dpkg -i cryptopro-csp_5.0_amd64.deb || apt-get install -f -y \
    && rm cryptopro-csp_5.0_amd64.deb
```

### 2. Установка лицензии CryptoPro

После установки CryptoPro CSP необходимо установить лицензию:

```dockerfile
# Копирование лицензионного файла
COPY cryptopro/license/license.txt /opt/cryptopro/license.txt

# Установка лицензии
RUN /opt/cprocsp/bin/amd64/cpconfig -license -set /opt/cryptopro/license.txt
```

### 3. Добавление ключевых контейнеров

#### Способ 1: Копирование готовых ключевых контейнеров

```dockerfile
# Копирование ключевых контейнеров
COPY cryptopro/keys/*.key /opt/cryptopro/keys/
COPY cryptopro/certs/*.crt /opt/cryptopro/certs/
COPY cryptopro/containers/*.000 /opt/cryptopro/containers/
```

#### Способ 2: Импорт ключей из файлов

```dockerfile
# Скрипт для импорта ключей
COPY scripts/import-cryptopro-keys.sh /usr/local/bin/
RUN chmod +x /usr/local/bin/import-cryptopro-keys.sh
```

Содержимое `import-cryptopro-keys.sh`:

```bash
#!/bin/bash
# Импорт закрытого ключа
/opt/cprocsp/bin/amd64/certmgr -inst -store uMy -file /opt/cryptopro/keys/private.key

# Импорт сертификата
/opt/cprocsp/bin/amd64/certmgr -inst -store uRoot -file /opt/cryptopro/certs/certificate.crt
```

### 4. Настройка прав доступа

```dockerfile
# Установка прав на ключевые файлы
RUN chmod 600 /opt/cryptopro/keys/*.key \
    && chmod 644 /opt/cryptopro/certs/*.crt \
    && chown -R root:root /opt/cryptopro
```

### 5. Переменные окружения для CryptoPro

```dockerfile
ENV CRYPTOPRO_HOME=/opt/cryptopro
ENV PATH=$PATH:/opt/cprocsp/bin/amd64
ENV LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/opt/cprocsp/lib/amd64
```

### 6. Проверка установки

Добавить в Dockerfile проверку установки:

```dockerfile
# Проверка установки CryptoPro
RUN /opt/cprocsp/bin/amd64/cpconfig -license -view || echo "License check failed"
```

## Примеры использования в коде

### Python с использованием pycryptopro

```python
from pycryptopro import CryptoPro

# Инициализация CryptoPro
crypto = CryptoPro()

# Подписание данных
signature = crypto.sign(data, key_path="/opt/cryptopro/keys/example.key")

# Проверка подписи
is_valid = crypto.verify(data, signature, cert_path="/opt/cryptopro/certs/example.crt")
```

### Использование через командную строку

```bash
# Подписание файла
/opt/cprocsp/bin/amd64/cryptcp -sign -f -pin <PIN> -cont <container_name> file.txt

# Проверка подписи
/opt/cprocsp/bin/amd64/cryptcp -verify file.txt.sgn
```

## Безопасность

⚠️ **ВАЖНО**: 

1. **Никогда не коммитьте реальные ключи в репозиторий**
2. Используйте секреты Docker или переменные окружения для передачи ключей
3. Храните ключи в зашифрованном виде
4. Используйте Docker secrets для production окружения

### Использование Docker Secrets

```yaml
# docker-compose.yml
services:
  app:
    secrets:
      - cryptopro_private_key
      - cryptopro_certificate

secrets:
  cryptopro_private_key:
    file: ./secrets/private.key
  cryptopro_certificate:
    file: ./secrets/certificate.crt
```

## Примеры ключей

В директории `cryptopro/keys/` и `cryptopro/certs/` находятся примеры файлов ключей:
- `example.key` - пример закрытого ключа
- `example.crt` - пример сертификата

**Замените эти файлы на реальные ключи перед использованием в production!**

## Дополнительные ресурсы

- [Официальная документация CryptoPro](https://www.cryptopro.ru/products/csp)
- [Руководство по установке CryptoPro CSP](https://www.cryptopro.ru/sites/default/files/products/csp/docs/csp_50_install_guide.pdf)
- [API CryptoPro для разработчиков](https://www.cryptopro.ru/products/csp/developers)

## Чеклист для добавления CryptoPro

- [ ] Установить CryptoPro CSP в Dockerfile
- [ ] Добавить лицензионный файл
- [ ] Скопировать ключевые контейнеры или файлы ключей
- [ ] Настроить права доступа
- [ ] Добавить переменные окружения
- [ ] Протестировать установку
- [ ] Настроить использование в приложении
- [ ] Настроить безопасное хранение ключей (Docker secrets)

## Примечания

- CryptoPro CSP требует лицензию для использования
- Для работы с ключами может потребоваться PIN-код
- Убедитесь, что версия CryptoPro CSP совместима с вашей системой
- Для production окружения используйте официальные ключи и сертификаты

