import subprocess
import sys
from pathlib import Path


def test_message_constant():
    """
    Проверяем, что константа MESSAGE содержит ожидаемую строку.
    """
    from app.get_mis_docs import MESSAGE

    assert (
        MESSAGE
        == "получения документов фз-44 по открытому api  getMisDocs"
    )


def test_script_output():
    """
    Проверяем, что при запуске скрипта печатается ожидаемая строка.
    """
    script_path = Path(__file__).resolve().parents[1] / "get_mis_docs.py"
    result = subprocess.run(
        [sys.executable, str(script_path)],
        check=True,
        capture_output=True,
        text=True,
    )
    assert (
        result.stdout.strip()
        == "получения документов фз-44 по открытому api  getMisDocs"
    )

