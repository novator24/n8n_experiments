## Codebase Web — Docker окружение для release1-0.0.1.zip

**Назначение**: поднять на Debian-контейнере окружение, которое:

- разворачивает zip-релиз `release1-0.0.1.zip`;
- по cron каждый день в **03:00** (и в будни, и в выходные) запускает Python‑скрипт, печатающий строку  
  `получения документов фз-44 по открытому api  getMisDocs`.

### Структура

- `Dockerfile` — образ на базе `debian:stable-slim` с установленным Python и cron.
- `docker-compose.yml` — сервис `get-mis-docs`, который билдит образ и монтирует логи.
- `app/get_mis_docs.py` — скрипт, который выводит требуемую строку.
- `app/tests/test_get_mis_docs.py` — простые тесты для проверки константы и вывода.

Ожидается, что в корне рядом с этими файлами лежит архив `release1-0.0.1.zip`.

### Сборка и запуск

```bash
docker compose build
docker compose up -d
```

Cron внутри контейнера будет каждый день в 03:00 выполнять:

```bash
cd /opt/app/release && python3 -m app.get_mis_docs
```

Логи складываются в `./logs` на хосте.

### Запуск тестов

Для запуска тестов (изнутри контейнера или локально при установленном Python):

```bash
python3 -m pytest app/tests
```

