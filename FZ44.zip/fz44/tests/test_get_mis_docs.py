import json
import sys
from pathlib import Path
from unittest import mock

import pytest

# Ensure src is on sys.path when running tests from project root
PROJECT_ROOT = Path(__file__).resolve().parents[1]
SRC_PATH = PROJECT_ROOT / "src"
if str(SRC_PATH) not in sys.path:
    sys.path.insert(0, str(SRC_PATH))

from fz44_etl import get_mis_docs  # noqa: E402


def test_build_request_params_basic():
    from datetime import date

    d1 = date(2024, 1, 1)
    d2 = date(2024, 1, 31)

    params = get_mis_docs.build_request_params(d1, d2, law_code="44-FZ")

    assert params["law"] == "44-FZ"
    assert params["dateFrom"] == "2024-01-01"
    assert params["dateTo"] == "2024-01-31"


@mock.patch("fz44_etl.get_mis_docs.requests.get")
def test_call_get_mis_docs_success(mock_get, tmp_path):
    mock_response = mock.Mock()
    mock_response.raise_for_status.return_value = None
    mock_response.json.return_value = {"items": [{"id": 1}]}
    mock_get.return_value = mock_response

    params = {"law": "44-FZ", "dateFrom": "2024-01-01", "dateTo": "2024-01-02"}
    payload = get_mis_docs.call_get_mis_docs(
        base_url="https://mis.example.org/api",
        api_key="TEST_KEY",
        params=params,
        timeout=5.0,
    )

    assert payload == {"items": [{"id": 1}]}
    mock_get.assert_called_once()
    called_url = mock_get.call_args[1]["params"]
    assert called_url["law"] == "44-FZ"


def test_save_response_creates_file(tmp_path):
    payload = {"items": [{"id": 1}]}
    out_dir = tmp_path / "out"

    path = get_mis_docs.save_response(payload, out_dir, suffix="44FZ")

    assert path.exists()
    data = json.loads(path.read_text(encoding="utf-8"))
    assert data == payload


@mock.patch("fz44_etl.get_mis_docs.call_get_mis_docs")
def test_main_integration_like_flow(mock_call, tmp_path, monkeypatch):
    mock_call.return_value = {"items": []}

    monkeypatch.setenv("GET_MIS_DOCS_BASE_URL", "https://mis.example.org/api")
    monkeypatch.setenv("GET_MIS_DOCS_API_KEY", "KEY")
    monkeypatch.setenv("GET_MIS_DOCS_OUTPUT_DIR", str(tmp_path))

    # Use fixed dates to avoid flakiness
    argv = ["--date-from", "2024-01-01", "--date-to", "2024-01-02"]
    get_mis_docs.main(argv)

    files = list(tmp_path.glob("mis_docs*json"))
    assert len(files) == 1

