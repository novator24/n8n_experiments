import argparse
import json
import logging
import os
from datetime import date, datetime
from pathlib import Path
from typing import Any, Dict, Optional

import requests
from dateutil.relativedelta import relativedelta


logger = logging.getLogger(__name__)


def _env(name: str, default: Optional[str] = None) -> Optional[str]:
    value = os.getenv(name, default)
    if value is None:
        logger.debug("ENV %s is not set, using default %r", name, default)
    return value


def get_default_date_range() -> tuple[date, date]:
    """Return (date_from, date_to) as today minus 1 day to today."""
    today = date.today()
    return today - relativedelta(days=1), today


def build_request_params(
    date_from: date,
    date_to: date,
    law_code: str = "44-FZ",
) -> Dict[str, Any]:
    """
    Build query parameters for the getMisDocs API call.

    Since public documentation is not available, this function assumes
    a typical REST contract used by similar MIS APIs and can be easily
    adapted once the real schema is known.
    """
    return {
        "law": law_code,
        "dateFrom": date_from.isoformat(),
        "dateTo": date_to.isoformat(),
    }


def call_get_mis_docs(
    base_url: str,
    api_key: Optional[str],
    params: Dict[str, Any],
    timeout: float = 30.0,
) -> Dict[str, Any]:
    """
    Call the (assumed) GET /getMisDocs endpoint.

    :param base_url: Base URL of the MIS API, e.g. https://mis.example.org/api
    :param api_key: Optional API key or token, passed as Authorization header.
    :param params: Query parameters.
    :param timeout: Request timeout in seconds.
    """
    url = base_url.rstrip("/") + "/getMisDocs"

    headers = {"Accept": "application/json"}
    if api_key:
        headers["Authorization"] = f"Bearer {api_key}"

    logger.info("Requesting MIS documents from %s", url)
    response = requests.get(url, params=params, headers=headers, timeout=timeout)
    response.raise_for_status()
    return response.json()


def save_response(payload: Dict[str, Any], output_dir: Path, suffix: str = "") -> Path:
    output_dir.mkdir(parents=True, exist_ok=True)
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    suffix_part = f"_{suffix}" if suffix else ""
    path = output_dir / f"mis_docs{suffix_part}_{ts}.json"
    with path.open("w", encoding="utf-8") as f:
        json.dump(payload, f, ensure_ascii=False, indent=2)
    logger.info("Saved MIS documents to %s", path)
    return path


def parse_args(argv: Optional[list[str]] = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Fetch 44-FZ documents from MIS getMisDocs open API."
    )
    parser.add_argument(
        "--date-from",
        help="Start date (YYYY-MM-DD). Defaults to yesterday.",
    )
    parser.add_argument(
        "--date-to",
        help="End date (YYYY-MM-DD). Defaults to today.",
    )
    parser.add_argument(
        "--output-dir",
        default=_env("GET_MIS_DOCS_OUTPUT_DIR", "/data"),
        help="Directory to write JSON payloads (default: /data or env GET_MIS_DOCS_OUTPUT_DIR).",
    )
    parser.add_argument(
        "--law",
        default=_env("GET_MIS_DOCS_LAW", "44-FZ"),
        help="Law code filter (default: 44-FZ or env GET_MIS_DOCS_LAW).",
    )
    return parser.parse_args(argv)


def main(argv: Optional[list[str]] = None) -> None:
    logging.basicConfig(
        level=os.getenv("LOG_LEVEL", "INFO"),
        format="%(asctime)s [%(levelname)s] %(name)s - %(message)s",
    )

    args = parse_args(argv)

    if args.date_from:
        date_from = datetime.strptime(args.date_from, "%Y-%m-%d").date()
    else:
        date_from, _ = get_default_date_range()

    if args.date_to:
        date_to = datetime.strptime(args.date_to, "%Y-%m-%d").date()
    else:
        _, date_to = get_default_date_range()

    base_url = _env("GET_MIS_DOCS_BASE_URL", "https://mis.example.org/api")
    api_key = _env("GET_MIS_DOCS_API_KEY")
    timeout = float(_env("GET_MIS_DOCS_TIMEOUT", "30.0"))

    params = build_request_params(date_from=date_from, date_to=date_to, law_code=args.law)
    payload = call_get_mis_docs(
        base_url=base_url,
        api_key=api_key,
        params=params,
        timeout=timeout,
    )
    save_response(payload, Path(args.output_dir), suffix=args.law.replace("-", ""))


if __name__ == "__main__":
    main()

