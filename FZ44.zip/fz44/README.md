## FZ-44 getMisDocs ETL

Проект содержит Docker-образ на базе последней Debian-платформы (python:3.12-slim-bookworm) и docker-compose для запуска Apache Airflow на Debian-сервере. Airflow с DockerOperator по расписанию в 09:00 (каждый день, будни и выходные) запускает контейнер с Python-скриптом получения документов по 44‑ФЗ через открытое API `getMisDocs`.

### Архитектура

- **Docker-образ `fz44-etl`**:  
  - Базовый образ: `python:3.12-slim-bookworm` (Debian 12).  
  - Устанавливает зависимости из `requirements.txt`.  
  - Копирует приложение `src/fz44_etl` и пример файлов CryptoPro из `cryptopro` в `/opt/cryptopro`.  
  - Точка входа по умолчанию: `python -m fz44_etl.get_mis_docs`.
- **Airflow**:
  - Запускается как сервис в `docker-compose.yml` на базе `apache/airflow:2.9.3-python3.12`.  
  - Использует `LocalExecutor` и PostgreSQL как БД.  
  - DAG `fz44_get_mis_docs` (файл `airflow/dags/fz44_get_mis_docs_dag.py`) по расписанию `0 9 * * *` вызывает `DockerOperator`, который стартует контейнер из образа `fz44-etl:latest`.
  - Для работы `DockerOperator` в Airflow-контейнер пробрасывается сокет Docker (`/var/run/docker.sock`).

### Описание (предполагаемого) открытого API getMisDocs

В открытом доступе не удалось найти официальную публичную документацию именно по методу `getMisDocs`, связанному с 44‑ФЗ. В проекте принята типовая REST‑модель, характерная для многих МИС‑API:

- **Базовый URL** (пример): `https://mis.example.org/api`.
- **Метод**: `GET /getMisDocs`.
- **Назначение**: получение списка документов/событий по закупкам по 44‑ФЗ за указанный период.
- **Параметры запроса (query)**:
  - `law` — код закона, по умолчанию `"44-FZ"`.  
  - `dateFrom` — начальная дата периода в формате `YYYY-MM-DD`.  
  - `dateTo` — конечная дата периода в формате `YYYY-MM-DD`.
- **Аутентификация**:
  - Через заголовок `Authorization: Bearer <API_KEY>` (по аналогии с другими МИС‑API).
- **Ответ**:
  - Тело в формате JSON, содержащее массив объектов документов (идентификатор, дата, статус, тип документа, ссылки на файлы и т.п.).

Фактический контракт конкретного сервиса МИС может отличаться; при интеграции следует свериться с реальной документацией поставщика API и при необходимости скорректировать параметры/схему ответа в функции `call_get_mis_docs`.

### Скрипт получения документов

- **Файл**: `src/fz44_etl/get_mis_docs.py`.  
- **Основная функция**: `main`, вызываемая через `python -m fz44_etl.get_mis_docs`.
- **Параметры CLI**:
  - `--date-from` — начало периода (`YYYY-MM-DD`), по умолчанию: вчера.  
  - `--date-to` — конец периода (`YYYY-MM-DD`), по умолчанию: сегодня.  
  - `--output-dir` — каталог для сохранения JSON (по умолчанию `/data` или значение из `GET_MIS_DOCS_OUTPUT_DIR`).  
  - `--law` — код закона (по умолчанию `"44-FZ"` или `GET_MIS_DOCS_LAW`).
- **Переменные окружения**:
  - `GET_MIS_DOCS_BASE_URL` — базовый URL API, по умолчанию `https://mis.example.org/api`.  
  - `GET_MIS_DOCS_API_KEY` — ключ/токен для Authorization (опционально).  
  - `GET_MIS_DOCS_TIMEOUT` — таймаут HTTP-запроса (секунды, по умолчанию `30.0`).  
  - `GET_MIS_DOCS_OUTPUT_DIR` — каталог вывода (если не задан через CLI).  
  - `GET_MIS_DOCS_LAW` — значение закона по умолчанию.  
  - `LOG_LEVEL` — уровень логирования (например, `INFO`, `DEBUG`).

Скрипт формирует параметры запроса (`law`, `dateFrom`, `dateTo`), вызывает `GET /getMisDocs`, проверяет HTTP‑код, парсит JSON‑ответ и сохраняет payload в файл `mis_docs_<LAW>_<timestamp>.json` в указанном каталоге.

### Docker и запуск на Debian-сервере

1. **Установить Docker и Docker Compose** на Debian‑сервере (актуальная документация Docker для Debian).  
2. **Склонировать репозиторий** и перейти в каталог `fz44`:  
   ```bash
   git clone <this-repo> && cd fz44
   ```
3. **Собрать ETL-образ**:
   ```bash
   docker compose --profile build build
   # или напрямую:
   # docker build -t fz44-etl:latest .
   ```
4. **Запустить Airflow через docker-compose**:
   ```bash
   docker compose up -d airflow
   ```
   После первого запуска может потребоваться время на инициализацию БД Airflow.
5. **Открыть веб-интерфейс Airflow**:  
   - URL: `http://<IP_СЕРВЕРА>:8080`  
   - Логин: `admin`  
   - Пароль: `admin` (задано в командной строке контейнера, рекомендуется сменить).
6. **Убедиться, что DAG `fz44_get_mis_docs` активен**. Он будет запускать контейнер `fz44-etl:latest` каждый день в 09:00.

### CryptoPro и ключи

- В образ по умолчанию копируется каталог `cryptopro` в `/opt/cryptopro`:
  - `cryptopro/keys/example.key` — пример приватного ключа (заглушка).  
  - `cryptopro/certs/example.crt` — пример сертификата (заглушка).
- Эти файлы **не являются рабочими** и предназначены лишь как пример структуры.
- В файле `TODO.md` описаны шаги по замене этих заглушек на реальные ключи и интеграции CryptoPro согласно официальным мануалам.

### Тесты

- Тесты находятся в каталоге `tests`, основной файл: `tests/test_get_mis_docs.py`.
- Для локального запуска тестов:
  ```bash
  pip install -r requirements.txt
  pytest
  ```
- Тесты используют `unittest.mock` для подмены HTTP‑вызовов и проверяют:
  - Формирование параметров запроса.  
  - Обработку успешного ответа и сохранение файла JSON.  
  - Обработку ошибок HTTP (через `raise_for_status`).

