from datetime import datetime

from airflow import DAG
from airflow.providers.docker.operators.docker import DockerOperator


with DAG(
    dag_id="fz44_get_mis_docs",
    description="Run fz44-etl container to fetch 44-FZ documents via getMisDocs API",
    start_date=datetime(2024, 1, 1),
    schedule="0 9 * * *",  # every day at 09:00 (будни и выходные)
    catchup=False,
    tags=["fz44", "mis", "docker"],
) as dag:
    run_get_mis_docs = DockerOperator(
        task_id="run_get_mis_docs",
        image="fz44-etl:latest",
        api_version="auto",
        auto_remove=True,
        docker_url="unix://var/run/docker.sock",
        network_mode="bridge",
        command="python -m fz44_etl.get_mis_docs",
        # Optionally pass env vars used by the script:
        # environment={
        #     "GET_MIS_DOCS_BASE_URL": "https://mis.example.org/api",
        #     "GET_MIS_DOCS_API_KEY": "change-me",
        #     "GET_MIS_DOCS_OUTPUT_DIR": "/data",
        # },
        mount_tmp_dir=False,
    )

